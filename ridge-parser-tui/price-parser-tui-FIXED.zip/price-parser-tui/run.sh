#!/bin/bash

# Quick run script for Price Parser TUI

cd "$(dirname "$0")"
python3 -m src.main
