#!/usr/bin/env node

/**
 * Test decision_update schema fix - verify updated_at column works
 * This tests that the technical_decisions table has the updated_at column
 * and that decision_update operations complete successfully
 */

const { Pool } = require('pg');

// Database connection
const pool = new Pool({
    host: 'localhost',
    port: 5432,
    database: 'aidis_production',
    user: 'ridgetop'
});

async function testDecisionUpdateSchema() {
    console.log('🔍 Testing decision_update schema fix...\n');
    
    try {
        // Test 1: Verify updated_at column exists
        console.log('📋 Test 1: Checking updated_at column exists...');
        const columnCheck = await pool.query(`
            SELECT column_name, data_type, is_nullable, column_default 
            FROM information_schema.columns 
            WHERE table_name = 'technical_decisions' 
            AND column_name = 'updated_at'
        `);
        
        if (columnCheck.rows.length === 0) {
            throw new Error('❌ updated_at column not found in technical_decisions table');
        }
        
        const column = columnCheck.rows[0];
        console.log(`✅ updated_at column found:`, {
            type: column.data_type,
            nullable: column.is_nullable,
            default: column.column_default
        });

        // Test 2: Create a test decision to update
        console.log('\n📋 Test 2: Creating test decision...');
        const createResult = await pool.query(`
            INSERT INTO technical_decisions (
                project_id, decision_type, title, description, rationale, impact_level
            ) 
            SELECT id, 'testing', 'Test Schema Fix', 'Testing updated_at column', 'Schema validation', 'low'
            FROM projects WHERE name = 'aidis-bootstrap'
            RETURNING id, decision_date, updated_at
        `);
        
        if (createResult.rows.length === 0) {
            throw new Error('❌ Failed to create test decision');
        }
        
        const testDecision = createResult.rows[0];
        console.log(`✅ Test decision created:`, {
            id: testDecision.id.substring(0, 8) + '...',
            decision_date: testDecision.decision_date,
            updated_at: testDecision.updated_at
        });

        // Test 3: Update the decision and verify updated_at changes
        console.log('\n📋 Test 3: Testing decision update...');
        
        // Wait a moment to ensure timestamp difference
        await new Promise(resolve => setTimeout(resolve, 100));
        
        const updateResult = await pool.query(`
            UPDATE technical_decisions 
            SET 
                outcome_status = 'successful',
                outcome_notes = 'Schema fix test completed successfully',
                lessons_learned = 'Always include updated_at in audit tables',
                updated_at = CURRENT_TIMESTAMP
            WHERE id = $1
            RETURNING id, decision_date, updated_at, outcome_status, outcome_notes, lessons_learned
        `, [testDecision.id]);
        
        if (updateResult.rows.length === 0) {
            throw new Error('❌ Failed to update test decision');
        }
        
        const updatedDecision = updateResult.rows[0];
        console.log(`✅ Decision updated successfully:`, {
            id: updatedDecision.id.substring(0, 8) + '...',
            decision_date: updatedDecision.decision_date,
            updated_at: updatedDecision.updated_at,
            outcome_status: updatedDecision.outcome_status,
            updated_at_changed: updatedDecision.updated_at > testDecision.updated_at
        });

        // Test 4: Verify all existing records have updated_at
        console.log('\n📋 Test 4: Checking all records have updated_at...');
        const recordCheck = await pool.query(`
            SELECT 
                COUNT(*) as total_records,
                COUNT(updated_at) as records_with_updated_at,
                MIN(updated_at) as earliest_updated_at,
                MAX(updated_at) as latest_updated_at
            FROM technical_decisions
        `);
        
        const stats = recordCheck.rows[0];
        console.log(`✅ Record statistics:`, stats);
        
        if (parseInt(stats.total_records) !== parseInt(stats.records_with_updated_at)) {
            throw new Error(`❌ ${stats.total_records - stats.records_with_updated_at} records missing updated_at`);
        }

        // Test 5: Clean up test data
        console.log('\n📋 Test 5: Cleaning up test data...');
        await pool.query('DELETE FROM technical_decisions WHERE title = $1', ['Test Schema Fix']);
        console.log('✅ Test data cleaned up');

        // Test 6: Verify schema matches MCP server expectations
        console.log('\n📋 Test 6: Verifying complete schema...');
        const schemaCheck = await pool.query(`
            SELECT column_name, data_type, is_nullable 
            FROM information_schema.columns 
            WHERE table_name = 'technical_decisions' 
            ORDER BY ordinal_position
        `);
        
        const requiredColumns = [
            'id', 'project_id', 'session_id', 'decision_type', 'title', 
            'description', 'rationale', 'decision_date', 'impact_level', 
            'outcome_status', 'outcome_notes', 'lessons_learned', 'updated_at'
        ];
        
        const actualColumns = schemaCheck.rows.map(row => row.column_name);
        const missingColumns = requiredColumns.filter(col => !actualColumns.includes(col));
        
        if (missingColumns.length > 0) {
            throw new Error(`❌ Missing required columns: ${missingColumns.join(', ')}`);
        }
        
        console.log(`✅ All ${requiredColumns.length} required columns present`);

        console.log('\n🎉 SUCCESS: decision_update schema fix verified!');
        console.log('✅ updated_at column exists and functions correctly');
        console.log('✅ All existing records have updated_at values');
        console.log('✅ Update operations work as expected');
        console.log('✅ Schema matches MCP server expectations');
        
        return {
            success: true,
            message: 'decision_update schema fix verified successfully',
            details: {
                updated_at_column_exists: true,
                total_records: parseInt(stats.total_records),
                records_with_updated_at: parseInt(stats.records_with_updated_at),
                schema_complete: true,
                test_update_successful: true
            }
        };

    } catch (error) {
        console.error('\n❌ SCHEMA TEST FAILED:', error.message);
        return {
            success: false,
            error: error.message
        };
    }
}

// Run the test
testDecisionUpdateSchema()
    .then(result => {
        console.log('\n📊 Final Result:', JSON.stringify(result, null, 2));
        process.exit(result.success ? 0 : 1);
    })
    .catch(error => {
        console.error('💥 Unexpected error:', error);
        process.exit(1);
    })
    .finally(() => {
        pool.end();
    });
