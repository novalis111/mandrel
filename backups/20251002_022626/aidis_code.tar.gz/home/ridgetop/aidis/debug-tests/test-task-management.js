#!/usr/bin/env node

/**
 * Comprehensive Test Script for T008: Task Management System
 * Tests all API endpoints and basic functionality
 */

const axios = require('axios');

const API_BASE = 'http://localhost:5000/api';
let authToken = null;
let testProjectId = null;
let testTaskIds = [];

// Test results tracking
const results = {
  passed: 0,
  failed: 0,
  tests: []
};

function logTest(name, passed, details = '') {
  results.tests.push({ name, passed, details });
  if (passed) {
    results.passed++;
    console.log(`✅ ${name}`);
  } else {
    results.failed++;
    console.log(`❌ ${name}: ${details}`);
  }
}

async function authenticate() {
  try {
    const response = await axios.post(`${API_BASE}/auth/login`, {
      username: 'admin',
      password: 'admin123!'
    });
    
    authToken = response.data.token;
    logTest('Authentication', !!authToken);
    
    // Set default headers
    axios.defaults.headers.common['Authorization'] = `Bearer ${authToken}`;
    return true;
  } catch (error) {
    logTest('Authentication', false, error.message);
    return false;
  }
}

async function getProject() {
  try {
    const response = await axios.get(`${API_BASE}/projects`);
    testProjectId = response.data.data?.projects?.[0]?.id;
    logTest('Get Project ID', !!testProjectId, `Project ID: ${testProjectId}`);
    return !!testProjectId;
  } catch (error) {
    logTest('Get Project ID', false, error.message);
    return false;
  }
}

async function testTaskCRUD() {
  console.log('\n🔄 Testing Task CRUD Operations...\n');

  // Test 1: Create Task
  try {
    const taskData = {
      project_id: testProjectId,
      title: 'Test Task - API Integration',
      description: 'Testing task creation via API',
      type: 'testing',
      priority: 'high',
      tags: ['api', 'testing', 'automation']
    };
    
    const response = await axios.post(`${API_BASE}/tasks`, taskData);
    const task = response.data.data?.task;
    
    if (task && task.id) {
      testTaskIds.push(task.id);
      logTest('Create Task', true, `Task ID: ${task.id}`);
    } else {
      logTest('Create Task', false, 'No task ID returned');
    }
  } catch (error) {
    logTest('Create Task', false, error.response?.data?.message || error.message);
  }

  // Test 2: Get Tasks
  try {
    const response = await axios.get(`${API_BASE}/tasks`, {
      params: { project_id: testProjectId }
    });
    
    const tasks = response.data.data?.tasks || [];
    logTest('Get Tasks', tasks.length > 0, `Found ${tasks.length} tasks`);
  } catch (error) {
    logTest('Get Tasks', false, error.response?.data?.message || error.message);
  }

  // Test 3: Get Single Task
  if (testTaskIds.length > 0) {
    try {
      const response = await axios.get(`${API_BASE}/tasks/${testTaskIds[0]}`);
      const task = response.data.data?.task;
      logTest('Get Single Task', !!task, `Task title: ${task?.title}`);
    } catch (error) {
      logTest('Get Single Task', false, error.response?.data?.message || error.message);
    }
  }

  // Test 4: Update Task
  if (testTaskIds.length > 0) {
    try {
      const updateData = {
        status: 'in_progress',
        priority: 'urgent',
        description: 'Updated description via API test'
      };
      
      const response = await axios.put(`${API_BASE}/tasks/${testTaskIds[0]}`, updateData);
      const task = response.data.data?.task;
      logTest('Update Task', task?.status === 'in_progress', `Status: ${task?.status}`);
    } catch (error) {
      logTest('Update Task', false, error.response?.data?.message || error.message);
    }
  }

  // Test 5: Get Task Dependencies
  if (testTaskIds.length > 0) {
    try {
      const response = await axios.get(`${API_BASE}/tasks/${testTaskIds[0]}/dependencies`);
      logTest('Get Task Dependencies', response.status === 200, 'Dependencies API accessible');
    } catch (error) {
      logTest('Get Task Dependencies', false, error.response?.data?.message || error.message);
    }
  }
}

async function testTaskFiltering() {
  console.log('\n🔄 Testing Task Filtering...\n');

  // Create multiple test tasks
  const testTasks = [
    { title: 'Backend Task', type: 'feature', priority: 'high', status: 'todo' },
    { title: 'Frontend Task', type: 'ui', priority: 'medium', status: 'in_progress' },
    { title: 'Database Task', type: 'database', priority: 'urgent', status: 'completed' }
  ];

  for (const taskData of testTasks) {
    try {
      const response = await axios.post(`${API_BASE}/tasks`, {
        ...taskData,
        project_id: testProjectId,
        description: `Test task for filtering: ${taskData.title}`
      });
      if (response.data.data?.task?.id) {
        testTaskIds.push(response.data.data.task.id);
      }
    } catch (error) {
      console.log(`Failed to create ${taskData.title}: ${error.message}`);
    }
  }

  // Test status filtering
  try {
    const response = await axios.get(`${API_BASE}/tasks`, {
      params: { 
        project_id: testProjectId,
        status: 'in_progress'
      }
    });
    const tasks = response.data.data?.tasks || [];
    const hasInProgressTask = tasks.some(task => task.status === 'in_progress');
    logTest('Filter by Status', hasInProgressTask, `Found ${tasks.length} in_progress tasks`);
  } catch (error) {
    logTest('Filter by Status', false, error.response?.data?.message || error.message);
  }

  // Test priority filtering
  try {
    const response = await axios.get(`${API_BASE}/tasks`, {
      params: { 
        project_id: testProjectId,
        priority: 'urgent'
      }
    });
    const tasks = response.data.data?.tasks || [];
    logTest('Filter by Priority', Array.isArray(tasks), `Found ${tasks.length} urgent tasks`);
  } catch (error) {
    logTest('Filter by Priority', false, error.response?.data?.message || error.message);
  }

  // Test search
  try {
    const response = await axios.get(`${API_BASE}/tasks`, {
      params: { 
        project_id: testProjectId,
        search: 'Backend'
      }
    });
    const tasks = response.data.data?.tasks || [];
    logTest('Search Tasks', Array.isArray(tasks), `Found ${tasks.length} tasks with "Backend"`);
  } catch (error) {
    logTest('Search Tasks', false, error.response?.data?.message || error.message);
  }
}

async function testTaskStats() {
  console.log('\n🔄 Testing Task Statistics...\n');

  try {
    const response = await axios.get(`${API_BASE}/tasks/stats`, {
      params: { project_id: testProjectId }
    });
    
    const stats = response.data.data?.stats;
    
    logTest('Get Task Stats', !!stats, `Total: ${stats?.total}, Completion: ${stats?.completion_rate}%`);
    logTest('Stats by Status', !!stats?.by_status, `Status breakdown: ${JSON.stringify(stats?.by_status)}`);
    logTest('Stats by Priority', !!stats?.by_priority, `Priority breakdown: ${JSON.stringify(stats?.by_priority)}`);
    
  } catch (error) {
    logTest('Get Task Stats', false, error.response?.data?.message || error.message);
  }
}

async function testBulkOperations() {
  console.log('\n🔄 Testing Bulk Operations...\n');

  if (testTaskIds.length >= 2) {
    try {
      const updates = testTaskIds.slice(0, 2).map(id => ({
        id,
        status: 'completed'
      }));
      
      const response = await axios.post(`${API_BASE}/tasks/bulk-update`, { updates });
      const updatedTasks = response.data.data?.tasks || [];
      
      logTest('Bulk Update Tasks', updatedTasks.length === 2, `Updated ${updatedTasks.length} tasks`);
      
    } catch (error) {
      logTest('Bulk Update Tasks', false, error.response?.data?.message || error.message);
    }
  } else {
    logTest('Bulk Update Tasks', false, 'Not enough tasks for bulk operation');
  }
}

async function testTaskAssignment() {
  console.log('\n🔄 Testing Task Assignment...\n');

  if (testTaskIds.length > 0) {
    try {
      // First get available agents
      const agentsResponse = await axios.get(`${API_BASE}/agents`);
      const agents = agentsResponse.data.data?.agents || [];
      
      if (agents.length > 0) {
        const response = await axios.post(`${API_BASE}/tasks/${testTaskIds[0]}/assign`, {
          assigned_to: agents[0].id
        });
        
        const task = response.data.data?.task;
        logTest('Assign Task to Agent', task?.assigned_to === agents[0].id, `Assigned to: ${agents[0].name}`);
      } else {
        logTest('Assign Task to Agent', false, 'No agents available');
      }
      
    } catch (error) {
      logTest('Assign Task to Agent', false, error.response?.data?.message || error.message);
    }
  }
}

async function testStatusChange() {
  console.log('\n🔄 Testing Status Changes...\n');

  if (testTaskIds.length > 0) {
    try {
      const response = await axios.post(`${API_BASE}/tasks/${testTaskIds[0]}/status`, {
        status: 'blocked',
        note: 'Blocked by external dependency'
      });
      
      const task = response.data.data?.task;
      logTest('Update Task Status', task?.status === 'blocked', `Status: ${task?.status}`);
      
    } catch (error) {
      logTest('Update Task Status', false, error.response?.data?.message || error.message);
    }
  }
}

async function cleanup() {
  console.log('\n🧹 Cleaning up test tasks...\n');

  for (const taskId of testTaskIds) {
    try {
      await axios.delete(`${API_BASE}/tasks/${taskId}`);
      logTest(`Delete Task ${taskId.substring(0, 8)}`, true);
    } catch (error) {
      logTest(`Delete Task ${taskId.substring(0, 8)}`, false, error.message);
    }
  }
}

async function runTests() {
  console.log('🚀 Starting T008 Task Management System Tests\n');

  // Authentication
  console.log('🔐 Testing Authentication...\n');
  const authenticated = await authenticate();
  if (!authenticated) {
    console.log('❌ Cannot proceed without authentication');
    return;
  }

  // Get project
  const hasProject = await getProject();
  if (!hasProject) {
    console.log('❌ Cannot proceed without a project');
    return;
  }

  // Run all tests
  await testTaskCRUD();
  await testTaskFiltering();
  await testTaskStats();
  await testBulkOperations();
  await testTaskAssignment();
  await testStatusChange();
  await cleanup();

  // Print summary
  console.log('\n📊 Test Summary');
  console.log('================');
  console.log(`Total tests: ${results.passed + results.failed}`);
  console.log(`✅ Passed: ${results.passed}`);
  console.log(`❌ Failed: ${results.failed}`);
  console.log(`📈 Success rate: ${Math.round((results.passed / (results.passed + results.failed)) * 100)}%`);

  if (results.failed > 0) {
    console.log('\n❌ Failed tests:');
    results.tests
      .filter(test => !test.passed)
      .forEach(test => console.log(`   • ${test.name}: ${test.details}`));
  }

  console.log('\n🎉 T008 Task Management System testing completed!');
  
  if (results.failed === 0) {
    console.log('🟢 All tests passed! The task management system is working correctly.');
  } else {
    console.log('🟡 Some tests failed. Check the details above.');
  }
}

// Run the tests
runTests().catch(error => {
  console.error('❌ Test runner failed:', error);
  process.exit(1);
});
