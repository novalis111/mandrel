// Complete storage inspection script
console.log('🔍 COMPLETE STORAGE INSPECTION');
console.log('===============================');

// 1. Check localStorage
console.log('\n📦 LOCAL STORAGE:');
if (localStorage.length === 0) {
    console.log('   ❌ Empty');
} else {
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        const value = localStorage.getItem(key);
        console.log(`   ${key}: ${value.substring(0, 100)}${value.length > 100 ? '...' : ''}`);
    }
}

// 2. Check sessionStorage
console.log('\n🗂️ SESSION STORAGE:');
if (sessionStorage.length === 0) {
    console.log('   ❌ Empty');
} else {
    for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        const value = sessionStorage.getItem(key);
        console.log(`   ${key}: ${value.substring(0, 100)}${value.length > 100 ? '...' : ''}`);
    }
}

// 3. Check cookies
console.log('\n🍪 COOKIES:');
if (document.cookie === '') {
    console.log('   ❌ No cookies');
} else {
    const cookies = document.cookie.split(';');
    cookies.forEach(cookie => {
        const [name, value] = cookie.trim().split('=');
        console.log(`   ${name}: ${value}`);
    });
}

// 4. Check IndexedDB (if any)
console.log('\n💾 INDEXEDDB:');
if (window.indexedDB) {
    // This is async, so it won't show immediately
    indexedDB.databases().then(databases => {
        if (databases.length === 0) {
            console.log('   ❌ No databases');
        } else {
            databases.forEach(db => {
                console.log(`   Database: ${db.name} (version ${db.version})`);
            });
        }
    }).catch(err => console.log('   ❌ Error checking IndexedDB:', err));
} else {
    console.log('   ❌ Not supported');
}

// 5. Check current URL and auth state
console.log('\n🌐 CURRENT STATE:');
console.log(`   URL: ${window.location.href}`);
console.log(`   Path: ${window.location.pathname}`);

// 6. Try to access any global auth state if it exists
console.log('\n⚛️ REACT STATE CHECK:');
setTimeout(() => {
    // Look for Zustand stores in window
    const globalKeys = Object.keys(window).filter(key => 
        key.includes('auth') || key.includes('store') || key.includes('zustand')
    );
    if (globalKeys.length > 0) {
        console.log('   Global auth-related keys found:', globalKeys);
    }
    
    // Check if any authentication info is in the DOM
    const authText = document.body.innerText;
    if (authText.includes('admin') && !authText.includes('Username: admin')) {
        console.log('   ⚠️ Found "admin" in page content - might be authenticated');
    }
    
    // Check for loading spinners or login forms
    const spinners = document.querySelectorAll('[class*="spin"], [class*="loading"]');
    const loginForms = document.querySelectorAll('form, [class*="login"]');
    
    if (spinners.length > 0) {
        console.log(`   🔄 Found ${spinners.length} loading elements`);
    }
    
    if (loginForms.length > 0) {
        console.log(`   📝 Found ${loginForms.length} form elements`);
    }
    
}, 500);

console.log('\n✅ Storage inspection complete!');
