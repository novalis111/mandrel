const axios = require('axios');

const API_BASE = 'http://localhost:5000/api';
const SESSION_ID = 'ca4c4cf3-f2ed-4033-b32c-0a603215add0';
const PROJECT_ID = 'c7ce10cb-e622-4c81-8ab4-3c0f52b73352'; // AIDIS COMMAND project

// Mock auth token (you may need to get a real one)
const AUTH_TOKEN = 'test-token';

const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Authorization': `Bearer ${AUTH_TOKEN}`,
    'X-Project-ID': PROJECT_ID
  }
});

async function testSessionEndpoints() {
  console.log('Testing Session API Endpoints...\n');

  try {
    // Test 1: Get session summaries
    console.log('1. Testing /sessions/summaries');
    try {
      const summaries = await api.get('/sessions/summaries?limit=5');
      console.log(`   ✓ Found ${summaries.data.data.summaries.length} session summaries`);
      if (summaries.data.data.summaries.length > 0) {
        const first = summaries.data.data.summaries[0];
        console.log(`   First session: ${first.duration_minutes}min, ${first.contexts_created} contexts, ${first.tasks_completed} tasks completed`);
      }
    } catch (err) {
      console.log(`   ✗ Error: ${err.response?.data?.error || err.message}`);
    }

    // Test 2: Get session detail
    console.log(`\n2. Testing /sessions/${SESSION_ID}`);
    try {
      const detail = await api.get(`/sessions/${SESSION_ID}`);
      const session = detail.data.data.session;
      console.log(`   ✓ Session details loaded`);
      console.log(`   - Duration: ${session.duration_minutes} minutes`);
      console.log(`   - Contexts: ${session.contexts.length}`);
      console.log(`   - Decisions: ${session.decisions.length}`);
      console.log(`   - Tasks: ${session.tasks.length}`);
      console.log(`   - Code Components: ${session.code_components.length}`);
      console.log(`   - Productivity Score: ${session.productivity_score}`);
    } catch (err) {
      console.log(`   ✗ Error: ${err.response?.data?.error || err.message}`);
    }

    // Test 3: Get stats by period
    console.log('\n3. Testing /sessions/stats-by-period');
    try {
      const stats = await api.get('/sessions/stats-by-period?period=day&limit=7');
      console.log(`   ✓ Got stats for ${stats.data.data.stats.length} days`);
      if (stats.data.data.stats.length > 0) {
        const recent = stats.data.data.stats[0];
        console.log(`   Most recent day: ${recent.session_count} sessions, ${recent.total_contexts} contexts`);
      }
    } catch (err) {
      console.log(`   ✗ Error: ${err.response?.data?.error || err.message}`);
    }

  } catch (error) {
    console.error('Test failed:', error.message);
  }
}

// Run tests
testSessionEndpoints().then(() => {
  console.log('\nTests complete!');
}).catch(err => {
  console.error('Fatal error:', err);
});