// Test script to verify project selector functionality
// This simulates the browser environment for testing

const axios = require('axios');

async function testProjectSelector() {
  console.log('🧪 Testing Project Selector Functionality\n');

  try {
    // Step 1: Login and get token
    console.log('1. Testing login...');
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      username: 'admin',
      password: 'admin123!'
    });

    if (!loginResponse.data.token) {
      throw new Error('No token received from login');
    }

    console.log('✅ Login successful');
    console.log(`   User: ${loginResponse.data.user.username}`);
    console.log(`   Token: ${loginResponse.data.token.substring(0, 20)}...`);

    // Step 2: Test projects API with token
    console.log('\n2. Testing projects API...');
    const projectsResponse = await axios.get('http://localhost:5000/api/projects?page=1&limit=100', {
      headers: {
        'Authorization': `Bearer ${loginResponse.data.token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!projectsResponse.data.success) {
      throw new Error('Projects API returned unsuccessful response');
    }

    const projects = projectsResponse.data.data.projects || [];
    console.log('✅ Projects API successful');
    console.log(`   Found ${projects.length} projects`);

    // Step 3: Verify project structure and active projects
    const activeProjects = projects.filter(p => p.status === 'active');
    console.log(`   Active projects: ${activeProjects.length}`);

    if (activeProjects.length > 0) {
      console.log('\n📋 Active Projects:');
      activeProjects.forEach((project, index) => {
        console.log(`   ${index + 1}. ${project.name} (${project.id.substring(0, 8)}...)`);
      });
    }

    // Step 4: Summary
    console.log('\n🎉 All tests passed!');
    console.log('\nProject Selector should now work when:');
    console.log('1. User logs in with admin/admin123!');
    console.log('2. Frontend stores the JWT token in localStorage');
    console.log('3. ProjectSwitcher component fetches projects with authentication');
    console.log('4. Projects are filtered by status === "active"');
    console.log('5. Dropdown shows the active projects');

  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.response?.data) {
      console.error('   API Response:', JSON.stringify(error.response.data, null, 2));
    }
    process.exit(1);
  }
}

// Run the test
testProjectSelector();