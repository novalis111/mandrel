const axios = require('axios');

async function testUpdatedSessionSummaries() {
  try {
    console.log('Testing updated session summaries endpoint...');
    
    // Test without authentication first to see error response format
    console.log('\n1. Testing endpoint accessibility...');
    const response = await axios.get('http://localhost:5000/api/sessions/summaries')
      .catch(error => {
        if (error.response && error.response.status === 401) {
          console.log('✅ Endpoint requires authentication as expected');
          return null;
        }
        throw error;
      });
    
    // Test the database query directly via health endpoint 
    console.log('\n2. Testing health endpoint...');
    const healthResponse = await axios.get('http://localhost:5000/api/health');
    console.log('Health status:', healthResponse.data);
    
    // Count total sessions that should appear
    console.log('\n3. Direct database verification...');
    const { exec } = require('child_process');
    
    exec(`psql -h localhost -p 5432 -d aidis_production -t -c "
      SELECT 
        'Total sessions that should appear in UI:' as info,
        count(*) as total_count
      FROM (
        SELECT id FROM user_sessions 
        UNION ALL 
        SELECT id FROM sessions
      ) as all_sessions;
    "`, (error, stdout, stderr) => {
      if (error) {
        console.log('DB query error:', error.message);
      } else {
        console.log('Database result:', stdout.trim());
      }
    });
    
    console.log('\n4. The updated SessionDetailService should now show ALL sessions:');
    console.log('   - Web sessions from user_sessions table');
    console.log('   - Agent sessions from sessions table (including Claude Code)');
    console.log('   - Each with session_type field: "web" or "claude-code-agent"');
    
  } catch (error) {
    if (error.response) {
      console.log('Error status:', error.response.status);
      console.log('Error data:', error.response.data);
    } else {
      console.log('Error:', error.message);
    }
  }
}

testUpdatedSessionSummaries();