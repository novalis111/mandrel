const { chromium } = require('playwright');

const WAIT_TIME = 2000;

async function testWebSocketFix() {
    console.log('🎯 WebSocket Fix Test - Testing Tasks page navigation...');
    
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();
    
    try {
        // Login first
        console.log('1. Navigating to login...');
        await page.goto('http://localhost:3001/login');
        await page.waitForSelector('#username');
        
        await page.fill('#username', 'admin');
        await page.fill('#password', 'admin123');
        await page.click('button[type="submit"]');
        
        await page.waitForURL('**/dashboard');
        console.log('✅ Login successful');
        
        // First visit to Tasks (should work)
        console.log('2. First visit to Tasks page...');
        await page.click('a[href="/tasks"]');
        await page.waitForURL('**/tasks');
        await page.waitForTimeout(WAIT_TIME);
        console.log('✅ First Tasks visit - OK');
        
        // Navigate away to Home
        console.log('3. Navigate to Home...');
        await page.click('a[href="/dashboard"]');
        await page.waitForURL('**/dashboard');
        await page.waitForTimeout(1000);
        console.log('✅ Home navigation - OK');
        
        // Return to Tasks (this is where the error occurred)
        console.log('4. Return to Tasks page...');
        
        // Listen for console errors
        let wsError = false;
        page.on('console', msg => {
            if (msg.type() === 'error' && msg.text().includes('Cannot access \'ws\' before initialization')) {
                wsError = true;
                console.log('❌ WebSocket initialization error detected:', msg.text());
            }
        });
        
        page.on('pageerror', error => {
            if (error.message.includes('Cannot access \'ws\' before initialization')) {
                wsError = true;
                console.log('❌ Page error detected:', error.message);
            }
        });
        
        await page.click('a[href="/tasks"]');
        await page.waitForURL('**/tasks');
        await page.waitForTimeout(WAIT_TIME);
        
        if (!wsError) {
            console.log('✅ Return to Tasks - NO WebSocket errors!');
            console.log('🎉 WebSocket initialization fix successful!');
        } else {
            console.log('❌ WebSocket error still occurs');
        }
        
        // Test one more navigation cycle to be sure
        console.log('5. Testing additional navigation cycle...');
        await page.click('a[href="/dashboard"]');
        await page.waitForTimeout(1000);
        await page.click('a[href="/tasks"]');
        await page.waitForTimeout(WAIT_TIME);
        
        if (!wsError) {
            console.log('✅ Second cycle - Still no errors!');
        }
        
        console.log('\n🎯 TEST COMPLETE');
        console.log(wsError ? '❌ Fix unsuccessful - errors detected' : '✅ Fix successful - no WebSocket errors');
        
    } catch (error) {
        console.error('Test failed:', error);
    }
    
    await browser.close();
}

testWebSocketFix().catch(console.error);
