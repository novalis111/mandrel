#!/usr/bin/env node

/**
 * Test decision parsing with actual MCP response
 */

const axios = require('axios');

async function testDecisionParsing() {
    console.log('🧪 Testing Decision Search with Project Context\n');
    
    try {
        // Get JWT token
        const loginResponse = await axios.post('http://localhost:5001/api/auth/login', {
            username: 'admin',
            password: 'admin123!'
        });
        
        const token = loginResponse.data.token;
        const headers = {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        };

        // Get aidis-bootstrap project
        const projectsResponse = await axios.get('http://localhost:5001/api/projects', { headers });
        const aidisBootstrapProject = projectsResponse.data.data?.projects?.find(
            p => p.name === 'aidis-bootstrap'
        );
        
        if (!aidisBootstrapProject) {
            console.error('❌ aidis-bootstrap project not found');
            return;
        }

        console.log(`✅ Testing with project: ${aidisBootstrapProject.name} (${aidisBootstrapProject.id})\n`);

        // Test decision search with project filter
        const searchResponse = await axios.get(
            `http://localhost:5001/api/decisions?query=system&project_id=${aidisBootstrapProject.id}`,
            { headers }
        );

        console.log('📊 Decision Search Results:');
        console.log('Success:', searchResponse.data.success);
        console.log('Total found:', searchResponse.data.data?.total || 0);
        console.log('Decisions returned:', searchResponse.data.data?.decisions?.length || 0);
        console.log('Message:', searchResponse.data.message);

        if (searchResponse.data.data?.decisions?.length > 0) {
            console.log('\n🔍 Sample Decision:');
            const decision = searchResponse.data.data.decisions[0];
            console.log(JSON.stringify(decision, null, 2));
        } else {
            console.log('\n❌ No decisions returned');
            console.log('Raw response data:', JSON.stringify(searchResponse.data.data, null, 2));
        }

        // Also test stats
        console.log('\n📈 Decision Stats:');
        const statsResponse = await axios.get('http://localhost:5001/api/decisions/stats', { headers });
        console.log('Stats:', JSON.stringify(statsResponse.data.data, null, 2));

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        if (error.response?.data) {
            console.error('Response:', JSON.stringify(error.response.data, null, 2));
        }
    }
}

testDecisionParsing().catch(console.error);
