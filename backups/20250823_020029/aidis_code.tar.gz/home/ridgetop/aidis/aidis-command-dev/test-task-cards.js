const { execSync, spawn } = require('child_process');
const fs = require('fs');

console.log('🧪 Testing Enhanced Task Cards UI');
console.log('=====================================\n');

// Helper function to wait
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Helper function to check if server is running
const checkServer = async (port, name) => {
  try {
    const result = execSync(`curl -s -o /dev/null -w "%{http_code}" http://localhost:${port}`, { encoding: 'utf8' });
    const isRunning = result.trim() === '200';
    console.log(`${isRunning ? '✅' : '❌'} ${name} (port ${port}): ${isRunning ? 'Running' : 'Not running'}`);
    return isRunning;
  } catch (error) {
    console.log(`❌ ${name} (port ${port}): Not running`);
    return false;
  }
};

// Helper function to start a server
const startServer = (command, cwd, logFile) => {
  console.log(`🚀 Starting: ${command} in ${cwd}`);
  const child = spawn('sh', ['-c', command], { 
    cwd, 
    detached: true,
    stdio: ['ignore', 'pipe', 'pipe']
  });
  
  // Log output to file
  const log = fs.createWriteStream(logFile, { flags: 'w' });
  child.stdout.pipe(log);
  child.stderr.pipe(log);
  
  // Don't wait for the child process to exit
  child.unref();
  return child;
};

async function main() {
  console.log('1️⃣ Checking current server status...');
  const backendRunning = await checkServer(5001, 'Backend');
  const frontendRunning = await checkServer(3000, 'Frontend');

  if (!backendRunning) {
    console.log('\n2️⃣ Starting backend server...');
    startServer('npm start', 'backend', '../backend-test.log');
    
    // Wait for backend to start
    for (let i = 0; i < 30; i++) {
      await sleep(2000);
      if (await checkServer(5001, 'Backend')) {
        break;
      }
      process.stdout.write('.');
    }
    console.log('\n');
  }

  if (!frontendRunning) {
    console.log('\n3️⃣ Starting frontend server...');
    startServer('npm start', 'frontend', '../frontend-test.log');
    
    // Wait for frontend to start
    for (let i = 0; i < 60; i++) {
      await sleep(3000);
      if (await checkServer(3000, 'Frontend')) {
        break;
      }
      process.stdout.write('.');
    }
    console.log('\n');
  }

  console.log('\n4️⃣ Final status check...');
  const finalBackendStatus = await checkServer(5001, 'Backend');
  const finalFrontendStatus = await checkServer(3000, 'Frontend');

  if (finalBackendStatus && finalFrontendStatus) {
    console.log('\n🎉 SERVERS READY!');
    console.log('==================');
    console.log('✅ Frontend: http://localhost:3000');
    console.log('✅ Backend:  http://localhost:5001');
    console.log('\n🎯 TASK CARDS ENHANCEMENT READY FOR TESTING!');
    console.log('\nFeatures to test:');
    console.log('- Navigate to http://localhost:3000/tasks');
    console.log('- Click the "Card View" tab');
    console.log('- Click on task cards to expand/collapse');
    console.log('- Test inline editing of status and assignee');
    console.log('- Verify responsive design on different screen sizes');
    console.log('- Test filtering and search functionality');
    console.log('- Observe smooth animations and hover effects');
  } else {
    console.log('\n❌ SERVERS NOT READY');
    console.log('Check log files: backend-test.log, frontend-test.log');
  }
}

main().catch(console.error);
