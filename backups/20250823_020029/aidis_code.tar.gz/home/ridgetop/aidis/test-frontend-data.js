#!/usr/bin/env node

const axios = require('axios');

const FRONTEND_URL = 'http://localhost:3000';
const BACKEND_URL = 'http://localhost:5000/api';

async function login() {
  try {
    console.log('🔐 Logging in...');
    
    const response = await axios.post(`${BACKEND_URL}/auth/login`, {
      username: 'admin',
      password: 'admin123!'
    });
    
    const token = response.data.token;
    console.log('✅ Login successful');
    return token;
  } catch (error) {
    console.error('❌ Login failed:', error.response?.data || error.message);
    throw error;
  }
}

async function testFrontendDataFetch() {
  try {
    console.log('\n🔄 Testing frontend dashboard data fetch simulation...');
    
    const token = await login();
    
    // Simulate the exact calls that dashboardApi.getDashboardStats() makes
    const [projectStatsResponse, contextStatsResponse] = await Promise.all([
      axios.get(`${BACKEND_URL}/projects/stats`, {
        headers: { Authorization: `Bearer ${token}` }
      }),
      axios.get(`${BACKEND_URL}/contexts/stats`, {
        headers: { Authorization: `Bearer ${token}` }
      })
    ]);
    
    console.log('\n📊 Raw project stats response structure:');
    console.log('- Response has success:', 'success' in projectStatsResponse.data);
    console.log('- Response has data:', 'data' in projectStatsResponse.data);
    console.log('- Data has stats:', projectStatsResponse.data.data && 'stats' in projectStatsResponse.data.data);
    
    console.log('\n📊 Raw context stats response structure:');
    console.log('- Response has success:', 'success' in contextStatsResponse.data);
    console.log('- Response has data:', 'data' in contextStatsResponse.data);
    
    // Test the exact mapping from the fixed dashboardApi.ts
    const projectStats = projectStatsResponse.data.data.stats;
    const contextStats = contextStatsResponse.data.data;
    
    console.log('\n🔍 Testing field access...');
    console.log('- contextStats.total_contexts:', contextStats.total_contexts);
    console.log('- projectStats.total_projects:', projectStats.total_projects);
    console.log('- projectStats.recent_activity:', projectStats.recent_activity);
    console.log('- projectStats.recent_activity.contexts_last_week:', projectStats.recent_activity?.contexts_last_week);
    console.log('- projectStats.recent_activity.sessions_last_week:', projectStats.recent_activity?.sessions_last_week);
    
    // Build the dashboard stats as the frontend would
    const dashboardStats = {
      contexts: contextStats.total_contexts,
      agents: 0,
      projects: projectStats.total_projects,
      activeTasks: 0,
      recentActivity: {
        contextsThisWeek: projectStats.recent_activity.contexts_last_week,
        sessionsThisWeek: projectStats.recent_activity.sessions_last_week
      }
    };
    
    console.log('\n✅ Final dashboard stats (what UI should show):');
    console.log(JSON.stringify(dashboardStats, null, 2));
    
    // Validate all values are numbers and not null/undefined
    const issues = [];
    if (typeof dashboardStats.contexts !== 'number' || isNaN(dashboardStats.contexts)) {
      issues.push(`contexts: ${dashboardStats.contexts} (${typeof dashboardStats.contexts})`);
    }
    if (typeof dashboardStats.projects !== 'number' || isNaN(dashboardStats.projects)) {
      issues.push(`projects: ${dashboardStats.projects} (${typeof dashboardStats.projects})`);
    }
    if (typeof dashboardStats.recentActivity.contextsThisWeek !== 'number' || isNaN(dashboardStats.recentActivity.contextsThisWeek)) {
      issues.push(`contextsThisWeek: ${dashboardStats.recentActivity.contextsThisWeek} (${typeof dashboardStats.recentActivity.contextsThisWeek})`);
    }
    if (typeof dashboardStats.recentActivity.sessionsThisWeek !== 'number' || isNaN(dashboardStats.recentActivity.sessionsThisWeek)) {
      issues.push(`sessionsThisWeek: ${dashboardStats.recentActivity.sessionsThisWeek} (${typeof dashboardStats.recentActivity.sessionsThisWeek})`);
    }
    
    if (issues.length > 0) {
      console.log('\n❌ Issues found:');
      issues.forEach(issue => console.log(`  - ${issue}`));
      return false;
    } else {
      console.log('\n✅ All dashboard stats are valid numbers!');
      return true;
    }
    
  } catch (error) {
    console.error('\n❌ Frontend data test failed:', error.response?.data || error.message);
    console.error('Stack:', error.stack);
    return false;
  }
}

async function main() {
  console.log('🧪 Testing frontend dashboard data fetch...\n');
  
  const success = await testFrontendDataFetch();
  
  if (success) {
    console.log('\n🎉 Frontend data fetch test PASSED! The issue should be fixed.');
  } else {
    console.log('\n💥 Frontend data fetch test FAILED! Further debugging needed.');
    process.exit(1);
  }
}

main().catch(console.error);
