#!/usr/bin/env node

const WebSocket = require('ws');
const jwt = require('jsonwebtoken');

// Test configuration
const BACKEND_URL = 'http://localhost:5000';
const WS_URL = 'ws://localhost:5000/ws';
const JWT_SECRET = process.env.JWT_SECRET || 'aidis-secret-key-change-in-production';

console.log('🔧 Testing WebSocket Authentication Fix...\n');

// Helper to create a test JWT token
function createTestToken(userId = 'test-user-123') {
  const payload = {
    userId,
    username: 'testuser',
    email: 'test@example.com',
    role: 'admin',
    tokenId: 'test-token-id'
  };
  
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
}

// Test 1: Valid Token Connection
async function testValidToken() {
  console.log('📋 Test 1: Valid JWT Token WebSocket Connection');
  
  return new Promise((resolve, reject) => {
    const token = createTestToken();
    const wsUrl = `${WS_URL}?token=${encodeURIComponent(token)}`;
    
    console.log(`   🔗 Connecting to: ${wsUrl.substring(0, 50)}...`);
    
    const ws = new WebSocket(wsUrl);
    let resolved = false;
    
    ws.on('open', () => {
      console.log('   ✅ WebSocket connected successfully with valid token');
      
      // Send a ping message
      ws.send(JSON.stringify({ type: 'ping' }));
    });
    
    ws.on('message', (data) => {
      const message = JSON.parse(data.toString());
      console.log('   📨 Received message:', message);
      
      if (message.type === 'connection_established') {
        console.log('   ✅ Connection established message received');
      } else if (message.type === 'pong') {
        console.log('   ✅ Ping/pong successful - WebSocket is working!');
        ws.close();
        if (!resolved) {
          resolved = true;
          resolve(true);
        }
      }
    });
    
    ws.on('close', (code, reason) => {
      console.log(`   ℹ️  WebSocket closed: ${code} ${reason}`);
      if (!resolved) {
        resolved = true;
        resolve(true);
      }
    });
    
    ws.on('error', (error) => {
      console.log('   ❌ WebSocket error:', error.message);
      if (!resolved) {
        resolved = true;
        resolve(false);
      }
    });
    
    // Timeout after 10 seconds
    setTimeout(() => {
      if (!resolved) {
        console.log('   ⏱️  Test timed out');
        ws.close();
        resolved = true;
        resolve(false);
      }
    }, 10000);
  });
}

// Test 2: Invalid Token Connection
async function testInvalidToken() {
  console.log('\n📋 Test 2: Invalid JWT Token (should be rejected)');
  
  return new Promise((resolve) => {
    const invalidToken = 'invalid.jwt.token';
    const wsUrl = `${WS_URL}?token=${encodeURIComponent(invalidToken)}`;
    
    console.log(`   🔗 Connecting to: ${wsUrl.substring(0, 50)}...`);
    
    const ws = new WebSocket(wsUrl);
    let resolved = false;
    
    ws.on('open', () => {
      console.log('   ❌ WebSocket opened with invalid token (this should not happen)');
      ws.close();
      if (!resolved) {
        resolved = true;
        resolve(false);
      }
    });
    
    ws.on('close', (code, reason) => {
      console.log(`   ✅ WebSocket correctly rejected invalid token: ${code} ${reason}`);
      if (!resolved) {
        resolved = true;
        resolve(true);
      }
    });
    
    ws.on('error', (error) => {
      console.log('   ✅ WebSocket error (expected for invalid token):', error.message);
      if (!resolved) {
        resolved = true;
        resolve(true);
      }
    });
    
    // Timeout after 5 seconds
    setTimeout(() => {
      if (!resolved) {
        console.log('   ✅ Connection properly rejected (timeout)');
        resolved = true;
        resolve(true);
      }
    }, 5000);
  });
}

// Test 3: No Token Connection
async function testNoToken() {
  console.log('\n📋 Test 3: No JWT Token (should be rejected)');
  
  return new Promise((resolve) => {
    const ws = new WebSocket(WS_URL);
    let resolved = false;
    
    ws.on('open', () => {
      console.log('   ❌ WebSocket opened without token (this should not happen)');
      ws.close();
      if (!resolved) {
        resolved = true;
        resolve(false);
      }
    });
    
    ws.on('close', (code, reason) => {
      console.log(`   ✅ WebSocket correctly rejected connection without token: ${code} ${reason}`);
      if (!resolved) {
        resolved = true;
        resolve(true);
      }
    });
    
    ws.on('error', (error) => {
      console.log('   ✅ WebSocket error (expected for no token):', error.message);
      if (!resolved) {
        resolved = true;
        resolve(true);
      }
    });
    
    // Timeout after 5 seconds
    setTimeout(() => {
      if (!resolved) {
        console.log('   ✅ Connection properly rejected (timeout)');
        resolved = true;
        resolve(true);
      }
    }, 5000);
  });
}

// Run all tests
async function runTests() {
  console.log('🚀 Starting WebSocket Authentication Tests\n');
  
  try {
    const test1Result = await testValidToken();
    const test2Result = await testInvalidToken();
    const test3Result = await testNoToken();
    
    console.log('\n📊 Test Results:');
    console.log(`   Valid Token: ${test1Result ? '✅ PASS' : '❌ FAIL'}`);
    console.log(`   Invalid Token Rejection: ${test2Result ? '✅ PASS' : '❌ FAIL'}`);
    console.log(`   No Token Rejection: ${test3Result ? '✅ PASS' : '❌ FAIL'}`);
    
    const allPassed = test1Result && test2Result && test3Result;
    
    console.log(`\n🎯 Overall Result: ${allPassed ? '✅ ALL TESTS PASSED' : '❌ SOME TESTS FAILED'}`);
    
    if (allPassed) {
      console.log('\n🎉 WebSocket authentication is working correctly!');
      console.log('   - Valid tokens are accepted');
      console.log('   - Invalid tokens are rejected');
      console.log('   - Missing tokens are rejected');
      console.log('   - JWT payload format is correct (userId field)');
      console.log('   - JWT secrets are consistent');
    } else {
      console.log('\n🔍 Some tests failed. Check the backend server logs for more details.');
      console.log('   - Ensure the backend server is running on localhost:5000');
      console.log('   - Verify JWT_SECRET is consistent across services');
      console.log('   - Check WebSocket endpoint configuration');
    }
    
  } catch (error) {
    console.error('❌ Test execution failed:', error);
  }
}

// Check if backend is running first
async function checkBackend() {
  try {
    const response = await fetch(`${BACKEND_URL}/api/health`, { 
      method: 'GET',
      timeout: 5000 
    });
    
    if (response.ok) {
      console.log('✅ Backend server is running\n');
      return true;
    } else {
      console.log('⚠️  Backend server responded with error:', response.status);
      return false;
    }
  } catch (error) {
    console.log('❌ Backend server is not running or not accessible');
    console.log('   Please start the backend server first:');
    console.log('   cd aidis-command/backend && npm start');
    return false;
  }
}

// Main execution
async function main() {
  console.log('🔧 WebSocket Authentication Fix Test Suite');
  console.log('==========================================');
  
  // For this test, we'll assume backend is running since we can't import fetch easily in Node.js
  // In a real scenario, you might want to add proper backend checks
  
  await runTests();
}

// Run the test
main().catch(console.error);
