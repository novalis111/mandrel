#!/usr/bin/env node

const WebSocket = require('ws');
const http = require('http');

const BACKEND_URL = 'http://localhost:5000';
const WS_URL = 'ws://localhost:5000/ws';

console.log('🧪 T008 Task Management System - Complete Test\n');

// Helper to make HTTP requests
function makeRequest(url, options = {}) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    
    const requestOptions = {
      hostname: urlObj.hostname,
      port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
      path: urlObj.pathname + urlObj.search,
      method: options.method || 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    };

    const req = http.request(requestOptions, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          const jsonData = JSON.parse(data);
          resolve({ status: res.statusCode, data: jsonData });
        } catch (e) {
          resolve({ status: res.statusCode, data: data });
        }
      });
    });

    req.on('error', reject);
    
    if (options.body) {
      req.write(typeof options.body === 'string' ? options.body : JSON.stringify(options.body));
    }
    
    req.end();
  });
}

// Test 1: Backend Health Check
async function testBackendHealth() {
  console.log('📋 Test 1: Backend Health Check');
  try {
    const response = await makeRequest(`${BACKEND_URL}/api/health`);
    console.log(`   ✅ Backend healthy: ${response.status === 200 ? 'YES' : 'NO'}`);
    return response.status === 200;
  } catch (error) {
    console.log('   ❌ Backend not accessible:', error.message);
    return false;
  }
}

// Test 2: Authentication Flow
async function testAuthentication() {
  console.log('\n📋 Test 2: Authentication Flow');
  try {
    const response = await makeRequest(`${BACKEND_URL}/api/auth/login`, {
      method: 'POST',
      body: {
        username: 'admin',
        password: 'admin123!'
      }
    });
    
    if (response.status === 200 && response.data.token) {
      console.log('   ✅ Login successful');
      console.log(`   📄 Token received: ${response.data.token.substring(0, 20)}...`);
      return response.data.token;
    } else {
      console.log('   ❌ Login failed:', response.data.error);
      return null;
    }
  } catch (error) {
    console.log('   ❌ Login request failed:', error.message);
    return null;
  }
}

// Test 3: Task API Endpoints
async function testTaskEndpoints(token) {
  console.log('\n📋 Test 3: Task API Endpoints');
  const headers = { 'Authorization': `Bearer ${token}` };
  
  try {
    // Test GET /api/tasks
    const getResponse = await makeRequest(`${BACKEND_URL}/api/tasks`, { headers });
    console.log(`   ✅ GET /api/tasks: ${getResponse.status === 200 ? 'SUCCESS' : 'FAILED'}`);
    console.log(`   📊 Initial tasks count: ${getResponse.data.data?.length || 0}`);
    
    // Test POST /api/tasks (create task)
    const createResponse = await makeRequest(`${BACKEND_URL}/api/tasks`, {
      method: 'POST',
      headers,
      body: {
        title: 'Test T008 Task',
        description: 'Testing the Task Management System endpoints',
        priority: 'medium',
        assigned_to: 'CodeAgent',
        project_id: 'c7ce10cb-e622-4c81-8ab4-3c0f52b73352' // AIDIS COMMAND project
      }
    });
    
    console.log(`   ✅ POST /api/tasks: ${createResponse.status === 201 ? 'SUCCESS' : 'FAILED'}`);
    if (createResponse.status !== 201) {
      console.log(`   ❌ Error details: ${JSON.stringify(createResponse.data)}`);
    }
    const taskId = createResponse.data.data?.task?.id;
    console.log(`   📝 Created task ID: ${taskId}`);
    
    // Test PUT /api/tasks/:id (update task)
    if (taskId) {
      const updateResponse = await makeRequest(`${BACKEND_URL}/api/tasks/${taskId}`, {
        method: 'PUT',
        headers,
        body: {
          status: 'in_progress',
          progress: 25
        }
      });
      
      console.log(`   ✅ PUT /api/tasks/${taskId}: ${updateResponse.status === 200 ? 'SUCCESS' : 'FAILED'}`);
    }
    
    return taskId;
    
  } catch (error) {
    console.log('   ❌ Task API test failed:', error.message);
    return null;
  }
}

// Test 4: WebSocket Connection with Real Token
async function testWebSocketConnection(token) {
  console.log('\n📋 Test 4: WebSocket Connection with Real Token');
  
  return new Promise((resolve) => {
    const wsUrl = `${WS_URL}?token=${encodeURIComponent(token)}`;
    console.log(`   🔗 Connecting to WebSocket...`);
    
    const ws = new WebSocket(wsUrl);
    let resolved = false;
    let connectionEstablished = false;
    let pingSuccessful = false;
    
    ws.on('open', () => {
      console.log('   ✅ WebSocket connection opened');
      // Send a ping to test bidirectional communication
      ws.send(JSON.stringify({ type: 'ping' }));
    });
    
    ws.on('message', (data) => {
      const message = JSON.parse(data.toString());
      console.log(`   📨 Received: ${message.type}`);
      
      if (message.type === 'connection_established') {
        connectionEstablished = true;
        console.log('   ✅ Connection established message received');
      } else if (message.type === 'pong') {
        pingSuccessful = true;
        console.log('   ✅ Ping/pong successful - WebSocket fully working!');
        ws.close();
        if (!resolved) {
          resolved = true;
          resolve({ success: true, connectionEstablished, pingSuccessful });
        }
      }
    });
    
    ws.on('close', (code, reason) => {
      console.log(`   ℹ️  WebSocket closed: ${code} ${reason}`);
      if (!resolved) {
        resolved = true;
        resolve({ success: connectionEstablished, connectionEstablished, pingSuccessful });
      }
    });
    
    ws.on('error', (error) => {
      console.log('   ❌ WebSocket error:', error.message);
      if (!resolved) {
        resolved = true;
        resolve({ success: false, connectionEstablished: false, pingSuccessful: false });
      }
    });
    
    // Timeout after 10 seconds
    setTimeout(() => {
      if (!resolved) {
        console.log('   ⏱️  WebSocket test timed out');
        ws.close();
        resolved = true;
        resolve({ success: false, connectionEstablished, pingSuccessful });
      }
    }, 10000);
  });
}

// Test 5: Task WebSocket Updates
async function testTaskWebSocketUpdates(token, taskId) {
  if (!taskId) {
    console.log('\n📋 Test 5: Task WebSocket Updates - SKIPPED (no task ID)');
    return { success: false };
  }
  
  console.log('\n📋 Test 5: Task WebSocket Updates');
  
  return new Promise((resolve) => {
    const wsUrl = `${WS_URL}?token=${encodeURIComponent(token)}`;
    const ws = new WebSocket(wsUrl);
    let resolved = false;
    let updateReceived = false;
    
    ws.on('open', () => {
      console.log('   🔗 WebSocket connected for task updates');
      
      // Update the task via API to trigger WebSocket notification
      setTimeout(async () => {
        try {
          await makeRequest(`${BACKEND_URL}/api/tasks/${taskId}`, {
            method: 'PUT',
            headers: { 'Authorization': `Bearer ${token}` },
            body: { status: 'completed', progress: 100 }
          });
          console.log('   📝 Task updated via API');
        } catch (error) {
          console.log('   ❌ Failed to update task via API');
        }
      }, 1000);
    });
    
    ws.on('message', (data) => {
      const message = JSON.parse(data.toString());
      console.log(`   📨 WebSocket message: ${message.type}`);
      
      if (message.type === 'task_updated' || message.type === 'task_status_changed') {
        updateReceived = true;
        console.log('   ✅ Task update received via WebSocket!');
        ws.close();
        if (!resolved) {
          resolved = true;
          resolve({ success: true, updateReceived });
        }
      }
    });
    
    ws.on('close', () => {
      if (!resolved) {
        resolved = true;
        resolve({ success: updateReceived, updateReceived });
      }
    });
    
    ws.on('error', (error) => {
      console.log('   ❌ WebSocket error:', error.message);
      if (!resolved) {
        resolved = true;
        resolve({ success: false, updateReceived: false });
      }
    });
    
    // Timeout after 15 seconds
    setTimeout(() => {
      if (!resolved) {
        console.log('   ⏱️  Task WebSocket update test timed out');
        ws.close();
        resolved = true;
        resolve({ success: false, updateReceived });
      }
    }, 15000);
  });
}

// Main test runner
async function runT008Tests() {
  console.log('🚀 Starting T008 Task Management System Tests\n');
  
  const results = {
    backendHealth: false,
    authentication: false,
    taskEndpoints: false,
    websocketConnection: false,
    websocketUpdates: false
  };
  
  // Test 1: Backend Health
  results.backendHealth = await testBackendHealth();
  if (!results.backendHealth) {
    console.log('\n❌ Backend not healthy - aborting tests');
    return results;
  }
  
  // Test 2: Authentication
  const token = await testAuthentication();
  results.authentication = !!token;
  if (!token) {
    console.log('\n❌ Authentication failed - aborting tests');
    return results;
  }
  
  // Test 3: Task Endpoints
  const taskId = await testTaskEndpoints(token);
  results.taskEndpoints = !!taskId;
  
  // Test 4: WebSocket Connection
  const wsResult = await testWebSocketConnection(token);
  results.websocketConnection = wsResult.success;
  
  // Test 5: Task WebSocket Updates
  if (results.websocketConnection) {
    const wsUpdateResult = await testTaskWebSocketUpdates(token, taskId);
    results.websocketUpdates = wsUpdateResult.success;
  }
  
  // Final Results
  console.log('\n📊 T008 Test Results:');
  console.log(`   Backend Health: ${results.backendHealth ? '✅ PASS' : '❌ FAIL'}`);
  console.log(`   Authentication: ${results.authentication ? '✅ PASS' : '❌ FAIL'}`);
  console.log(`   Task Endpoints: ${results.taskEndpoints ? '✅ PASS' : '❌ FAIL'}`);
  console.log(`   WebSocket Connection: ${results.websocketConnection ? '✅ PASS' : '❌ FAIL'}`);
  console.log(`   WebSocket Updates: ${results.websocketUpdates ? '✅ PASS' : '❌ FAIL'}`);
  
  const allPassed = Object.values(results).every(result => result === true);
  console.log(`\n🎯 Overall Result: ${allPassed ? '✅ ALL TESTS PASSED' : '❌ SOME TESTS FAILED'}`);
  
  if (allPassed) {
    console.log('\n🎉 T008 Task Management System is working perfectly!');
    console.log('   - Backend API endpoints functional');
    console.log('   - JWT authentication working');
    console.log('   - WebSocket connection successful');
    console.log('   - Real-time task updates working');
    console.log('\n🚀 Ready for frontend integration!');
  } else {
    console.log('\n🔍 Some tests failed. Issues found:');
    if (!results.backendHealth) console.log('   - Backend server not responding');
    if (!results.authentication) console.log('   - Authentication system failure');
    if (!results.taskEndpoints) console.log('   - Task API endpoints not working');
    if (!results.websocketConnection) console.log('   - WebSocket connection failing');
    if (!results.websocketUpdates) console.log('   - Real-time task updates not working');
  }
  
  return results;
}

// Run the tests
runT008Tests().catch(console.error);
