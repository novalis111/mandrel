const axios = require('axios');

async function testFixedSessions() {
  try {
    console.log('Testing the fixed session API...');
    
    // Test without authentication to see what happens
    try {
      const response = await axios.get('http://localhost:5000/api/projects/sessions/all?limit=50');
      console.log(`✅ Found ${response.data.data.total} sessions:`);
      
      // Group by session type 
      const sessionTypes = {};
      response.data.data.sessions.forEach(session => {
        const type = session.session_type || 'unknown';
        sessionTypes[type] = (sessionTypes[type] || 0) + 1;
      });
      
      console.log('Session breakdown:');
      Object.entries(sessionTypes).forEach(([type, count]) => {
        console.log(`  ${type}: ${count} sessions`);
      });
      
      console.log('\nMost recent sessions:');
      response.data.data.sessions.slice(0, 5).forEach((session, i) => {
        console.log(`  ${i + 1}. ${session.session_type} - ${session.project_name || 'No project'} - ${session.created_at}`);
      });
      
    } catch (error) {
      if (error.response && error.response.status === 401) {
        console.log('❌ Endpoint requires authentication');
        console.log('Response:', error.response.data);
      } else {
        throw error;
      }
    }
    
  } catch (error) {
    console.log('Error:', error.message);
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Data:', error.response.data);
    }
  }
}

testFixedSessions();