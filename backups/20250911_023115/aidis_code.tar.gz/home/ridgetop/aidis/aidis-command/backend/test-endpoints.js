// Simple test script for API endpoints
const { spawn } = require('child_process');
const http = require('http');

async function testEndpoints() {
  console.log('🧪 Testing AIDIS Command Backend API Endpoints...\n');
  
  // Start the server in background
  const server = spawn('npm', ['start'], { 
    cwd: '/home/ridgetop/aidis/aidis-command/backend',
    detached: true,
    stdio: 'pipe'
  });

  // Wait for server to start
  await new Promise(resolve => setTimeout(resolve, 3000));

  const baseUrl = 'http://localhost:5000';
  const endpoints = [
    { path: '/', name: 'Root' },
    { path: '/api/health', name: 'Health' },
    { path: '/api/db-status', name: 'Database Status' },
    { path: '/api/version', name: 'Version' },
    { path: '/api/nonexistent', name: '404 Test' }
  ];

  console.log('Testing endpoints...\n');
  
  for (const endpoint of endpoints) {
    try {
      const response = await fetch(`${baseUrl}${endpoint.path}`);
      const text = await response.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        data = { raw: text };
      }
      
      console.log(`✅ ${endpoint.name} (${endpoint.path}):`);
      console.log(`   Status: ${response.status}`);
      console.log(`   Success: ${data.success || 'N/A'}`);
      console.log(`   Response: ${JSON.stringify(data).substring(0, 100)}...`);
      console.log('');
    } catch (error) {
      console.log(`❌ ${endpoint.name} (${endpoint.path}): ${error.message}\n`);
    }
  }

  // Kill the server
  process.kill(-server.pid);
  console.log('🎉 API endpoint testing complete!\n');
}

testEndpoints().catch(console.error);
