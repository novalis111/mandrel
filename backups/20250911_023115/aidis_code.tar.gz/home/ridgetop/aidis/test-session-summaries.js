const axios = require('axios');

async function testSessionSummaries() {
  try {
    console.log('Testing session summaries endpoint...');
    
    // Test the API directly without auth first to see what happens
    const response = await axios.get('http://localhost:5000/api/sessions/summaries', {
      headers: {
        'Authorization': 'Bearer dummy-token' // Dummy token to test
      }
    });
    
    console.log('Response status:', response.status);
    console.log('Response data:', JSON.stringify(response.data, null, 2));
    
  } catch (error) {
    if (error.response) {
      console.log('Error status:', error.response.status);
      console.log('Error data:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('Error:', error.message);
    }
  }
}

testSessionSummaries();