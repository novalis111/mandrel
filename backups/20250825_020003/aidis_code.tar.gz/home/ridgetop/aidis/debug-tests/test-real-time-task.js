#!/usr/bin/env node

const axios = require('axios');

async function testRealTimeTask() {
  try {
    // Authenticate
    const authResponse = await axios.post('http://localhost:5000/api/auth/login', {
      username: 'admin',
      password: 'admin123!'
    });
    
    const token = authResponse.data.token;
    
    // Create a task to test real-time updates
    const taskResponse = await axios.post('http://localhost:5000/api/tasks', {
      project_id: '70595833-1317-481d-87ca-a7e57428acb8',
      title: 'Real-Time WebSocket Test Task',
      description: 'This task was created to test WebSocket real-time updates',
      type: 'testing',
      priority: 'high',
      tags: ['websocket', 'real-time', 'test']
    }, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log('✅ Task created successfully:', taskResponse.data.data.task.id);
    console.log('📡 Check the browser - you should see the task appear in real-time!');
    
    // Wait a moment, then clean up
    setTimeout(async () => {
      try {
        await axios.delete(`http://localhost:5000/api/tasks/${taskResponse.data.data.task.id}`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        console.log('🧹 Test task cleaned up');
      } catch (error) {
        console.log('⚠️ Failed to clean up test task');
      }
    }, 5000);
    
  } catch (error) {
    console.error('❌ Error:', error.response?.data?.message || error.message);
  }
}

testRealTimeTask();
