#!/usr/bin/env node

/**
 * Direct test of AIDIS Navigation Tools using HTTP bridge
 * Tests the Phase 1 Navigation Enhancement implementation
 */

import http from 'http';

async function makeRequest(toolName, args = {}) {
  const postData = JSON.stringify({
    method: 'tools/call',
    params: {
      name: toolName,
      arguments: args
    }
  });

  const options = {
    hostname: 'localhost',
    port: 8080,
    path: '/mcp',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve({ error: 'Parse error', raw: data });
        }
      });
    });

    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

async function testNavigationTools() {
  console.log('🧪 Testing AIDIS Navigation Enhancement - Phase 1\n');

  // Test 1: aidis_help
  console.log('📚 Testing aidis_help...');
  try {
    const helpResult = await makeRequest('aidis_help', {});
    console.log('✅ aidis_help succeeded!');
    if (helpResult.result?.content?.[0]?.text) {
      console.log(helpResult.result.content[0].text.substring(0, 200) + '...\n');
    }
  } catch (error) {
    console.log('❌ aidis_help failed:', error.message, '\n');
  }

  // Test 2: aidis_explain
  console.log('🔧 Testing aidis_explain...');
  try {
    const explainResult = await makeRequest('aidis_explain', { toolName: 'context_search' });
    console.log('✅ aidis_explain succeeded!');
    if (explainResult.result?.content?.[0]?.text) {
      console.log(explainResult.result.content[0].text.substring(0, 200) + '...\n');
    }
  } catch (error) {
    console.log('❌ aidis_explain failed:', error.message, '\n');
  }

  // Test 3: aidis_examples
  console.log('💡 Testing aidis_examples...');
  try {
    const examplesResult = await makeRequest('aidis_examples', { toolName: 'context_store' });
    console.log('✅ aidis_examples succeeded!');
    if (examplesResult.result?.content?.[0]?.text) {
      console.log(examplesResult.result.content[0].text.substring(0, 200) + '...\n');
    }
  } catch (error) {
    console.log('❌ aidis_examples failed:', error.message, '\n');
  }

  console.log('🎯 Navigation Enhancement Testing Complete!');
}

testNavigationTools().catch(console.error);
