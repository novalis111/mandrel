async function testTaskCreation() {
  console.log('🧪 Testing task creation API...');

  try {
    // Test 1: Create task with minimal data (only title)
    console.log('\n📝 Test 1: Creating task with only title...');
    
    const response1 = await fetch('http://localhost:3001/mcp/call-tool', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer admin-token'
      },
      body: JSON.stringify({
        name: 'task_create',
        arguments: {
          title: 'Test task with defaults only'
        }
      })
    });

    const result1 = await response1.json();
    console.log('Response status:', response1.status);
    console.log('Result 1:', result1.success ? '✅ SUCCESS' : '❌ FAILED');
    if (result1.success) {
      console.log('Task created:', result1.result.content[0].text.split('\n').slice(0, 4).join('\n'));
    } else {
      console.log('Error:', result1.error);
    }

    // Test 2: Create task with explicit type and priority
    console.log('\n📝 Test 2: Creating task with explicit type and priority...');
    
    const response2 = await fetch('http://localhost:3001/mcp/call-tool', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer admin-token'
      },
      body: JSON.stringify({
        name: 'task_create',
        arguments: {
          title: 'Test task with explicit params',
          description: 'This task has explicit type and priority',
          type: 'feature',
          priority: 'high'
        }
      })
    });

    const result2 = await response2.json();
    console.log('Response status:', response2.status);
    console.log('Result 2:', result2.success ? '✅ SUCCESS' : '❌ FAILED');
    if (result2.success) {
      console.log('Task created:', result2.result.content[0].text.split('\n').slice(0, 4).join('\n'));
    } else {
      console.log('Error:', result2.error);
    }

    // Test 3: List tasks to verify they were created
    console.log('\n📝 Test 3: Listing tasks...');
    
    const response3 = await fetch('http://localhost:3001/mcp/call-tool', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer admin-token'
      },
      body: JSON.stringify({
        name: 'task_list',
        arguments: {}
      })
    });

    const result3 = await response3.json();
    console.log('Response status:', response3.status);
    console.log('Result 3:', result3.success ? '✅ SUCCESS' : '❌ FAILED');
    if (result3.success) {
      console.log('Tasks found:', result3.result.content[0].text.split('\n').slice(0, 8).join('\n'));
    } else {
      console.log('Error:', result3.error);
    }

    console.log('\n🎉 Task creation API test completed!');

  } catch (error) {
    console.error('❌ Test failed with error:', error.message);
  }
}

testTaskCreation();
