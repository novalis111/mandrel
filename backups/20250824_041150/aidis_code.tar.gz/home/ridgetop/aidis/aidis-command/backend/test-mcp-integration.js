#!/usr/bin/env node

/**
 * Test MCP Integration for T010 Naming Registry
 * This script tests the full authentication and MCP connection flow
 */

const http = require('http');

async function makeRequest(url, method = 'GET', data = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
      path: urlObj.pathname + urlObj.search,
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };

    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          resolve({ status: res.statusCode, data: parsed, headers: res.headers });
        } catch (e) {
          resolve({ status: res.statusCode, data: body, headers: res.headers });
        }
      });
    });

    req.on('error', reject);
    
    if (data) {
      req.write(JSON.stringify(data));
    }
    req.end();
  });
}

async function testAuthentication() {
  console.log('🔐 Testing Authentication...');
  
  // Try known admin credentials
  const credentials = [
    { username: 'admin', password: 'admin123!' },
    { username: 'admin', password: 'admin123' },
    { username: 'admin', password: 'password' },
    { username: 'admin', password: 'admin' }
  ];

  for (const cred of credentials) {
    console.log(`Trying: ${cred.username}/${cred.password}`);
    
    try {
      const response = await makeRequest(
        'http://localhost:5000/api/auth/login',
        'POST',
        cred
      );
      
      if (response.status === 200 && response.data.token) {
        console.log(`✅ Login successful with ${cred.username}/${cred.password}`);
        return response.data.token;
      } else {
        console.log(`❌ Failed: ${response.data.message || response.data}`);
      }
    } catch (error) {
      console.log(`❌ Error: ${error.message}`);
    }
  }
  
  return null;
}

async function testMCPConnection() {
  console.log('\n🔌 Testing AIDIS MCP Connection...');
  
  try {
    const response = await makeRequest(
      'http://localhost:8080/mcp/tools/naming_stats',
      'POST',
      { arguments: {} }
    );
    
    if (response.status === 200) {
      console.log('✅ AIDIS MCP server is responding');
      console.log('Response:', JSON.stringify(response.data, null, 2));
      return true;
    } else {
      console.log(`❌ MCP server error: ${response.status} - ${response.data}`);
      return false;
    }
  } catch (error) {
    console.log(`❌ MCP connection failed: ${error.message}`);
    return false;
  }
}

async function testNamingEndpoint(token) {
  console.log('\n📝 Testing Naming Stats Endpoint...');
  
  try {
    const response = await makeRequest(
      'http://localhost:5000/api/naming/stats',
      'GET',
      null,
      { 'Authorization': `Bearer ${token}` }
    );
    
    if (response.status === 200) {
      console.log('✅ Naming stats endpoint working');
      console.log('Response:', JSON.stringify(response.data, null, 2));
      return true;
    } else {
      console.log(`❌ Naming stats failed: ${response.status} - ${JSON.stringify(response.data)}`);
      return false;
    }
  } catch (error) {
    console.log(`❌ Naming stats error: ${error.message}`);
    return false;
  }
}

async function testNameCheck(token) {
  console.log('\n🔍 Testing Name Check Endpoint...');
  
  try {
    const response = await makeRequest(
      'http://localhost:5000/api/naming/check/TestName',
      'GET',
      null,
      { 'Authorization': `Bearer ${token}` }
    );
    
    if (response.status === 200) {
      console.log('✅ Name check endpoint working');
      console.log('Response:', JSON.stringify(response.data, null, 2));
      return true;
    } else {
      console.log(`❌ Name check failed: ${response.status} - ${JSON.stringify(response.data)}`);
      return false;
    }
  } catch (error) {
    console.log(`❌ Name check error: ${error.message}`);
    return false;
  }
}

async function main() {
  console.log('🚀 T010 MCP Integration Test\n');
  
  // Test MCP connection first
  const mcpWorking = await testMCPConnection();
  if (!mcpWorking) {
    console.log('\n❌ CRITICAL: AIDIS MCP server not responding. Check if AIDIS is running.');
    process.exit(1);
  }
  
  // Test authentication
  const token = await testAuthentication();
  if (!token) {
    console.log('\n❌ CRITICAL: Authentication failed. Need to set up admin user properly.');
    process.exit(1);
  }
  
  // Test naming endpoints
  const namingStats = await testNamingEndpoint(token);
  const nameCheck = await testNameCheck(token);
  
  console.log('\n📊 Integration Test Results:');
  console.log(`🔌 AIDIS MCP Server: ${mcpWorking ? '✅' : '❌'}`);
  console.log(`🔐 Authentication: ${token ? '✅' : '❌'}`);
  console.log(`📊 Naming Stats: ${namingStats ? '✅' : '❌'}`);
  console.log(`🔍 Name Check: ${nameCheck ? '✅' : '❌'}`);
  
  if (mcpWorking && token && namingStats && nameCheck) {
    console.log('\n🎉 ALL TESTS PASSED! T010 integration is working.');
  } else {
    console.log('\n❌ SOME TESTS FAILED. Integration needs fixing.');
  }
}

main().catch(console.error);
