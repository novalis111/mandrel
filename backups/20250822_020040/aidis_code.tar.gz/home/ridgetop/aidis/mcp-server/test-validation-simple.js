import { validationMiddleware } from './dist/middleware/validation.js';

console.log('🧪 Testing task_create validation fix...');

// Test 1: Only title (should pass with defaults)
console.log('\n📝 Test 1: Only title provided');
const test1 = validationMiddleware('task_create', {
  title: 'Test task'
});
console.log('Result:', test1.success ? '✅ PASSED' : '❌ FAILED');
if (!test1.success) console.log('Error:', test1.error);
if (test1.success) console.log('Data:', test1.data);

// Test 2: Title with type and priority
console.log('\n📝 Test 2: Title with explicit type and priority');
const test2 = validationMiddleware('task_create', {
  title: 'Test task 2',
  type: 'feature',
  priority: 'high'
});
console.log('Result:', test2.success ? '✅ PASSED' : '❌ FAILED');
if (!test2.success) console.log('Error:', test2.error);
if (test2.success) console.log('Data:', test2.data);

// Test 3: Title with description
console.log('\n📝 Test 3: Title with description');
const test3 = validationMiddleware('task_create', {
  title: 'Test task 3',
  description: 'This is a test task'
});
console.log('Result:', test3.success ? '✅ PASSED' : '❌ FAILED');
if (!test3.success) console.log('Error:', test3.error);
if (test3.success) console.log('Data:', test3.data);

console.log('\n✨ Validation test completed!');
