import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';

async function testTaskCreate() {
  console.log('🚀 Testing task creation fix...');
  
  try {
    // Create MCP client
    const transport = new StdioClientTransport({
      command: 'node',
      args: ['dist/server.js'],
      cwd: '/home/ridgetop/aidis/mcp-server'
    });

    const client = new Client({
      name: 'test-client',
      version: '1.0.0'
    }, {
      capabilities: {}
    });

    await client.connect(transport);
    console.log('✅ Connected to MCP server');

    // Test 1: Create task with minimal parameters (only title - should use defaults)
    console.log('\n📝 Test 1: Creating task with only title (should use defaults)...');
    const result1 = await client.callTool('task_create', {
      title: 'Test task with defaults'
    });

    if (result1.content && result1.content[0] && result1.content[0].text.includes('✅ Task created successfully!')) {
      console.log('✅ Test 1 PASSED: Task created with defaults');
      console.log('📋 Result:', result1.content[0].text.split('\n').slice(0, 5).join('\n'));
    } else {
      console.log('❌ Test 1 FAILED:', JSON.stringify(result1, null, 2));
    }

    // Test 2: Create task with explicit type and priority
    console.log('\n📝 Test 2: Creating task with explicit type and priority...');
    const result2 = await client.callTool('task_create', {
      title: 'Test task with explicit params',
      description: 'Testing task creation with explicit type and priority',
      type: 'feature',
      priority: 'high'
    });

    if (result2.content && result2.content[0] && result2.content[0].text.includes('✅ Task created successfully!')) {
      console.log('✅ Test 2 PASSED: Task created with explicit params');
      console.log('📋 Result:', result2.content[0].text.split('\n').slice(0, 5).join('\n'));
    } else {
      console.log('❌ Test 2 FAILED:', JSON.stringify(result2, null, 2));
    }

    // Test 3: List tasks to verify they were created
    console.log('\n📝 Test 3: Listing tasks to verify creation...');
    const listResult = await client.callTool('task_list', {});
    
    if (listResult.content && listResult.content[0] && listResult.content[0].text) {
      console.log('✅ Test 3 PASSED: Task list retrieved');
      console.log('📋 Tasks:', listResult.content[0].text.split('\n').slice(0, 10).join('\n'));
    } else {
      console.log('❌ Test 3 FAILED:', JSON.stringify(listResult, null, 2));
    }

    await client.close();
    console.log('\n🎉 Task creation fix test completed!');
    
  } catch (error) {
    console.error('❌ Test failed with error:', error.message);
    console.error('Stack:', error.stack);
    process.exit(1);
  }
}

testTaskCreate().catch(console.error);
