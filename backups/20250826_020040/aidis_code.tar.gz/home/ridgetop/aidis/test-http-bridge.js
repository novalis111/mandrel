#!/usr/bin/env node

/**
 * Test HTTP Bridge for Claude Code Integration
 * 
 * This script tests all 38 MCP tools via HTTP endpoints to verify
 * Claude Code compatibility while preserving MCP STDIO functionality.
 */

const tools = [
  // System Health (2 tools)
  'aidis_ping',
  'aidis_status',
  
  // Context Management (3 tools) 
  'context_store',
  'context_search', 
  'context_stats',
  
  // Project Management (6 tools)
  'project_list',
  'project_create',
  'project_switch',
  'project_current', 
  'project_info',
  'project_insights',
  
  // Naming Registry (4 tools)
  'naming_register',
  'naming_check',
  'naming_suggest',
  'naming_stats',
  
  // Technical Decisions (4 tools)
  'decision_record',
  'decision_search', 
  'decision_update',
  'decision_stats',
  
  // Multi-Agent Coordination (11 tools)
  'agent_register',
  'agent_list',
  'agent_status',
  'agent_join',
  'agent_leave',
  'agent_sessions', 
  'agent_message',
  'agent_messages',
  'task_create',
  'task_list', 
  'task_update',
  
  // Code Analysis (5 tools)
  'code_analyze',
  'code_components',
  'code_dependencies',
  'code_impact',
  'code_stats',
  
  // Smart Search & AI (3 tools)
  'smart_search',
  'get_recommendations',
  'context_get_recent'
];

const BASE_URL = 'http://localhost:8080/mcp/tools';

async function testTool(toolName, args = {}) {
  try {
    const response = await fetch(`${BASE_URL}/${toolName}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ arguments: args })
    });
    
    const result = await response.json();
    
    if (response.ok && result.success) {
      return { success: true, data: result.result };
    } else {
      return { success: false, error: result.error || 'Unknown error' };
    }
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function testAllTools() {
  console.log('🚀 Testing HTTP Bridge for Claude Code Integration');
  console.log(`🔧 Testing ${tools.length} MCP tools via HTTP endpoints\n`);
  
  let passed = 0;
  let failed = 0;
  
  for (const toolName of tools) {
    process.stdout.write(`Testing ${toolName}... `);
    
    let args = {};
    
    // Provide minimal required args for tools that need them
    switch (toolName) {
      case 'context_store':
        args = { content: 'Test context', type: 'code' };
        break;
      case 'context_search':
        args = { query: 'test' };
        break;
      case 'project_create':
        args = { name: 'test-project-' + Date.now() };
        break;
      case 'project_switch':
        args = { project: 'aidis-bootstrap' };
        break;
      case 'project_info':
        args = { project: 'aidis-bootstrap' };
        break;
      case 'naming_check':
        args = { proposedName: 'testFunction', entityType: 'function' };
        break;
      case 'naming_register':
        args = { canonicalName: 'testVar', entityType: 'variable' };
        break;
      case 'naming_suggest':
        args = { description: 'user authentication', entityType: 'function' };
        break;
      case 'decision_record':
        args = { 
          title: 'Test Decision',
          description: 'Test description', 
          rationale: 'Test rationale',
          decisionType: 'architecture',
          impactLevel: 'low'
        };
        break;
      case 'decision_search':
        args = { query: 'test' };
        break;
      case 'decision_update':
        args = { decisionId: '1', outcomeStatus: 'successful' };
        break;
      case 'agent_register':
        args = { name: 'test-agent-' + Date.now() };
        break;
      case 'agent_status':
        args = { agentId: 'test-agent', status: 'active' };
        break;
      case 'agent_join':
        args = { agentId: 'test-agent' };
        break;
      case 'agent_leave':
        args = { agentId: 'test-agent' };
        break;
      case 'agent_message':
        args = { fromAgentId: 'test-agent', content: 'Hello' };
        break;
      case 'task_create':
        args = { title: 'Test Task' };
        break;
      case 'task_update':
        args = { taskId: '1', status: 'completed' };
        break;
      case 'code_analyze':
        args = { filePath: '/home/ridgetop/aidis/README.md' };
        break;
      case 'code_dependencies':
        args = { componentId: '1' };
        break;
      case 'code_impact':
        args = { componentId: '1' };
        break;
      case 'smart_search':
        args = { query: 'project management' };
        break;
      case 'get_recommendations':
        args = { context: 'building a REST API', type: 'implementation' };
        break;
      case 'context_get_recent':
        args = { limit: 5 };
        break;
    }
    
    const result = await testTool(toolName, args);
    
    if (result.success) {
      console.log('✅ PASS');
      passed++;
    } else {
      console.log(`❌ FAIL: ${result.error}`);
      failed++;
    }
  }
  
  console.log(`\n📊 Test Results:`);
  console.log(`✅ Passed: ${passed}/${tools.length}`);
  console.log(`❌ Failed: ${failed}/${tools.length}`);
  console.log(`📈 Success Rate: ${Math.round(passed/tools.length*100)}%`);
  
  if (passed === tools.length) {
    console.log('\n🎉 ALL TESTS PASSED! HTTP Bridge is Claude Code ready!');
  } else {
    console.log('\n⚠️  Some tests failed. Check tool implementations.');
  }
}

if (require.main === module) {
  testAllTools().catch(console.error);
}
