#!/usr/bin/env node

/**
 * Test T010 Naming Registry Authentication & Mock Data Fix
 * Tests both critical issues identified by QaAgent:
 * 1. Authentication working correctly
 * 2. Real AIDIS MCP integration (not mock data)
 */

const http = require('http');

class T010Test {
  constructor() {
    this.baseUrl = 'http://localhost:5000';
    this.authToken = null;
    this.results = [];
  }

  async makeRequest(method, path, data = null, headers = {}) {
    return new Promise((resolve, reject) => {
      const url = new URL(path, this.baseUrl);
      const options = {
        hostname: url.hostname,
        port: url.port,
        path: url.pathname + url.search,
        method,
        headers: {
          'Content-Type': 'application/json',
          ...headers
        }
      };

      const req = http.request(options, (res) => {
        let responseData = '';
        
        res.on('data', (chunk) => {
          responseData += chunk;
        });
        
        res.on('end', () => {
          try {
            const parsed = JSON.parse(responseData);
            resolve({ status: res.statusCode, data: parsed, headers: res.headers });
          } catch (e) {
            resolve({ status: res.statusCode, data: responseData, headers: res.headers });
          }
        });
      });

      req.on('error', reject);
      
      if (data) {
        req.write(JSON.stringify(data));
      }
      
      req.end();
    });
  }

  async testStep(name, testFn) {
    try {
      console.log(`\n🧪 Testing: ${name}`);
      const result = await testFn();
      this.results.push({ name, success: true, result });
      console.log(`✅ PASS: ${name}`);
      return result;
    } catch (error) {
      this.results.push({ name, success: false, error: error.message });
      console.log(`❌ FAIL: ${name} - ${error.message}`);
      throw error;
    }
  }

  async verifyAdminUserExists() {
    return this.testStep('Verify admin user exists', async () => {
      // Test login with existing admin user
      const response = await this.makeRequest('POST', '/api/auth/login', {
        username: 'admin',
        password: 'admin123!'
      });

      if (response.status !== 200) {
        throw new Error(`Admin login failed: ${JSON.stringify(response.data)}`);
      }

      if (!response.data.token) {
        throw new Error('No token returned from admin login');
      }

      console.log('✅ Admin user exists and password works');
      return response.data;
    });
  }

  async testAuthentication() {
    const result = await this.testStep('User authentication', async () => {
      const response = await this.makeRequest('POST', '/api/auth/login', {
        username: 'admin',
        password: 'admin123!'
      });

      if (response.status !== 200) {
        throw new Error(`Login failed: ${JSON.stringify(response.data)}`);
      }

      if (!response.data.token) {
        throw new Error('No token returned from login');
      }

      this.authToken = response.data.token;
      console.log('✅ Authentication successful, token obtained');
      return response.data;
    });
    
    return result;
  }

  async testNamingAuthRequired() {
    return this.testStep('Naming API requires authentication', async () => {
      // Test without auth token - should fail
      const response = await this.makeRequest('GET', '/api/naming/stats');
      
      if (response.status !== 401) {
        throw new Error(`Expected 401 unauthorized, got ${response.status}: ${JSON.stringify(response.data)}`);
      }

      if (!response.data.message || !response.data.message.includes('Authorization header is required')) {
        throw new Error('Expected authorization required message');
      }

      console.log('✅ Naming API correctly requires authentication');
      return response.data;
    });
  }

  async testNamingStatsWithAuth() {
    return this.testStep('Naming stats with authentication', async () => {
      const response = await this.makeRequest('GET', '/api/naming/stats', null, {
        'Authorization': `Bearer ${this.authToken}`
      });
      
      if (response.status !== 200) {
        throw new Error(`Expected 200, got ${response.status}: ${JSON.stringify(response.data)}`);
      }

      if (!response.data.success) {
        throw new Error(`API returned failure: ${response.data.message}`);
      }

      const stats = response.data.data;
      
      // Verify it's real AIDIS data, not mock
      if (!stats.total_names && stats.total_names !== 0) {
        throw new Error('Missing total_names - not real AIDIS data');
      }

      if (!stats.by_type || typeof stats.by_type !== 'object') {
        throw new Error('Missing or invalid by_type - not real AIDIS data');
      }

      console.log('✅ Naming stats returns real AIDIS data:', JSON.stringify(stats, null, 2));
      return response.data;
    });
  }

  async testNamingSearchWithAuth() {
    return this.testStep('Naming search with authentication', async () => {
      const response = await this.makeRequest('GET', '/api/naming?limit=10', null, {
        'Authorization': `Bearer ${this.authToken}`
      });
      
      if (response.status !== 200) {
        throw new Error(`Expected 200, got ${response.status}: ${JSON.stringify(response.data)}`);
      }

      if (!response.data.success) {
        throw new Error(`API returned failure: ${response.data.message}`);
      }

      const result = response.data.data;
      
      // Check if it's using AIDIS data (not the old hardcoded mock)
      if (!response.data.message.includes('generated from AIDIS data')) {
        throw new Error('Search not using AIDIS data integration');
      }

      console.log(`✅ Naming search returns ${result.total} entries generated from AIDIS data`);
      
      if (result.entries && result.entries.length > 0) {
        console.log(`Sample entry: ${JSON.stringify(result.entries[0], null, 2)}`);
      }
      
      return response.data;
    });
  }

  async testNamingCheckWithAuth() {
    return this.testStep('Naming check with authentication', async () => {
      const testName = 'TestComponentName';
      const response = await this.makeRequest('GET', `/api/naming/check/${testName}`, null, {
        'Authorization': `Bearer ${this.authToken}`
      });
      
      if (response.status !== 200) {
        throw new Error(`Expected 200, got ${response.status}: ${JSON.stringify(response.data)}`);
      }

      if (!response.data.success) {
        throw new Error(`API returned failure: ${response.data.message}`);
      }

      const result = response.data.data;
      
      // Verify it's calling real AIDIS MCP (not mock)
      if (typeof result.available !== 'boolean') {
        throw new Error('Missing availability result from AIDIS');
      }

      console.log(`✅ Naming check for "${testName}": available=${result.available}`);
      return response.data;
    });
  }

  async testNamingRegisterWithAuth() {
    return this.testStep('Naming register with authentication', async () => {
      const testName = `TestRegistration${Date.now()}`;
      const response = await this.makeRequest('POST', '/api/naming/register', {
        name: testName,
        type: 'component',
        context: 'Test component registration'
      }, {
        'Authorization': `Bearer ${this.authToken}`
      });
      
      if (response.status !== 201) {
        throw new Error(`Expected 201, got ${response.status}: ${JSON.stringify(response.data)}`);
      }

      if (!response.data.success) {
        throw new Error(`API returned failure: ${response.data.message}`);
      }

      console.log(`✅ Successfully registered name "${testName}"`);
      return response.data;
    });
  }

  async runAllTests() {
    console.log('🚀 T010 Naming Registry - Critical Fixes Validation');
    console.log('='.repeat(60));
    
    try {
      // Setup
      await this.verifyAdminUserExists();
      await this.testAuthentication();
      
      // Authentication tests
      await this.testNamingAuthRequired();
      
      // AIDIS integration tests (with auth)
      await this.testNamingStatsWithAuth();
      await this.testNamingSearchWithAuth();  
      await this.testNamingCheckWithAuth();
      await this.testNamingRegisterWithAuth();
      
      // Summary
      console.log('\n' + '='.repeat(60));
      console.log('🎉 ALL TESTS PASSED!');
      console.log(`✅ ${this.results.filter(r => r.success).length}/${this.results.length} tests successful`);
      
      console.log('\n📊 Critical Issues Status:');
      console.log('✅ Issue #1 FIXED: Mock data replaced with real AIDIS MCP integration');
      console.log('✅ Issue #2 FIXED: Authentication working correctly');
      console.log('\n🚢 T010 Naming Registry ready for production deployment!');
      
    } catch (error) {
      console.log('\n' + '='.repeat(60));
      console.log('❌ TEST SUITE FAILED');
      console.log(`❌ ${this.results.filter(r => !r.success).length}/${this.results.length} tests failed`);
      
      const failures = this.results.filter(r => !r.success);
      if (failures.length > 0) {
        console.log('\n💥 Failures:');
        failures.forEach(f => console.log(`   - ${f.name}: ${f.error}`));
      }
      
      throw error;
    }
  }
}

// Run tests
const test = new T010Test();
test.runAllTests().catch(error => {
  console.error('\n💥 Test execution failed:', error.message);
  process.exit(1);
});
