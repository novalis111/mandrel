#!/usr/bin/env node

const axios = require('axios');
const BASE_URL = 'http://localhost:5000/api';

async function testContextBrowser() {
    console.log('🔧 AIDIS Context Browser Complete Test\n');
    
    try {
        // Step 1: Login to get token
        console.log('🔑 Step 1: Authenticating...');
        const authResponse = await axios.post(`${BASE_URL}/auth/login`, {
            username: 'admin',
            password: 'admin123!'
        });
        
        const token = authResponse.data.token;
        console.log('✅ Authentication successful');
        
        // Set up headers for authenticated requests
        const authHeaders = {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        };
        
        // Step 2: Test context search endpoint
        console.log('\n🔍 Step 2: Testing context search...');
        const searchResponse = await axios.get(`${BASE_URL}/contexts?limit=5`, {
            headers: authHeaders
        });
        
        const contexts = searchResponse.data.data;
        console.log(`✅ Context search successful - Found ${contexts.total} contexts`);
        console.log(`📋 Showing ${contexts.contexts.length} contexts`);
        
        // Step 3: Test context stats
        console.log('\n📊 Step 3: Testing context stats...');
        const statsResponse = await axios.get(`${BASE_URL}/contexts/stats`, {
            headers: authHeaders
        });
        
        console.log('✅ Context stats retrieved:', statsResponse.data.data);
        
        // Step 4: Test semantic search if there are contexts
        if (contexts.contexts.length > 0) {
            console.log('\n🧠 Step 4: Testing semantic search...');
            const semanticResponse = await axios.post(`${BASE_URL}/contexts/search`, {
                query: 'context browser',
                limit: 3
            }, {
                headers: authHeaders
            });
            
            console.log(`✅ Semantic search successful - Found ${semanticResponse.data.data.total} matches`);
            
            // Step 5: Test individual context retrieval
            if (contexts.contexts.length > 0) {
                console.log('\n📄 Step 5: Testing individual context retrieval...');
                const contextId = contexts.contexts[0].id;
                const contextResponse = await axios.get(`${BASE_URL}/contexts/${contextId}`, {
                    headers: authHeaders
                });
                
                console.log('✅ Individual context retrieved successfully');
                console.log(`📝 Context type: ${contextResponse.data.data.type}`);
                console.log(`📅 Created: ${contextResponse.data.data.created_at}`);
            }
        }
        
        console.log('\n🎉 ALL CONTEXT BROWSER TESTS PASSED!');
        console.log('\n📋 Summary:');
        console.log('✅ Authentication working');
        console.log('✅ Context search working'); 
        console.log('✅ Context stats working');
        console.log('✅ Semantic search working');
        console.log('✅ Individual context retrieval working');
        
    } catch (error) {
        console.error('❌ Test failed:', error.response ? {
            status: error.response.status,
            statusText: error.response.statusText,
            data: error.response.data
        } : error.message);
    }
}

testContextBrowser();
