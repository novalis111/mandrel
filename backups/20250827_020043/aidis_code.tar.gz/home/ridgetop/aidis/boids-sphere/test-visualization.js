/**
 * test-visualization.js - Quick test to verify Phase 2 visualization setup
 * Run with: node test-visualization.js
 */

// Test imports
async function testImports() {
    console.log('🧪 Testing Phase 2 Three.js Visualization Setup');
    console.log('==============================================\n');
    
    let testsPassed = 0;
    let testsTotal = 0;
    
    // Test 1: Core math modules (Phase 1)
    testsTotal++;
    try {
        const { Vector3D } = await import('./src/math/Vector3D.js');
        const { BoidsEngine } = await import('./src/math/BoidsEngine.js');
        
        const vector = new Vector3D(1, 2, 3);
        const engine = new BoidsEngine();
        
        if (vector.magnitude() > 0 && engine.boids) {
            console.log('✅ Test 1: Core math modules import - PASSED');
            testsPassed++;
        }
    } catch (error) {
        console.log('❌ Test 1: Core math modules import - FAILED:', error.message);
    }
    
    // Test 2: Visualization system imports
    testsTotal++;
    try {
        const viz = await import('./src/visualization/index.js');
        
        if (viz.SceneManager && viz.CameraControls && viz.SphereGeometry && 
            viz.BoidVisualizer && viz.VisualizationSystem) {
            console.log('✅ Test 2: Visualization modules import - PASSED');
            testsPassed++;
        } else {
            console.log('❌ Test 2: Visualization modules import - FAILED: Missing exports');
        }
    } catch (error) {
        console.log('❌ Test 2: Visualization modules import - FAILED:', error.message);
    }
    
    // Test 3: Three.js availability
    testsTotal++;
    try {
        const THREE = await import('three');
        
        if (THREE.Scene && THREE.PerspectiveCamera && THREE.WebGLRenderer) {
            console.log('✅ Test 3: Three.js availability - PASSED');
            testsPassed++;
        }
    } catch (error) {
        console.log('❌ Test 3: Three.js availability - FAILED:', error.message);
    }
    
    // Test 4: Package.json scripts
    testsTotal++;
    try {
        const fs = await import('fs');
        const packageJson = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
        
        if (packageJson.dependencies.three && packageJson.dependencies['dat.gui']) {
            console.log('✅ Test 4: Required dependencies - PASSED');
            testsPassed++;
        }
    } catch (error) {
        console.log('❌ Test 4: Required dependencies - FAILED:', error.message);
    }
    
    // Test 5: File structure
    testsTotal++;
    try {
        const fs = await import('fs');
        const files = [
            './src/visualization/SceneManager.js',
            './src/visualization/CameraControls.js',
            './src/visualization/SphereGeometry.js',
            './src/visualization/BoidVisualizer.js',
            './src/visualization/VisualizationSystem.js',
            './src/visualization/main.js',
            './index.html'
        ];
        
        let allExist = true;
        for (const file of files) {
            if (!fs.existsSync(file)) {
                allExist = false;
                console.log(`   Missing: ${file}`);
            }
        }
        
        if (allExist) {
            console.log('✅ Test 5: File structure - PASSED');
            testsPassed++;
        } else {
            console.log('❌ Test 5: File structure - FAILED');
        }
    } catch (error) {
        console.log('❌ Test 5: File structure - FAILED:', error.message);
    }
    
    // Test 6: Integration test (create minimal scene)
    testsTotal++;
    try {
        const { SceneManager } = await import('./src/visualization/SceneManager.js');
        const { SphereGeometry } = await import('./src/visualization/SphereGeometry.js');
        const { BoidSwarm } = await import('./src/visualization/BoidVisualizer.js');
        
        // Mock DOM element
        const mockContainer = {
            clientWidth: 800,
            clientHeight: 600,
            appendChild: () => {}
        };
        
        const sceneManager = new SceneManager(mockContainer);
        const sphereGeometry = new SphereGeometry(50);
        const boidSwarm = new BoidSwarm();
        
        if (sceneManager.getScene() && sphereGeometry.getRadius() === 50 && 
            boidSwarm.getBoidCount() === 0) {
            console.log('✅ Test 6: Component integration - PASSED');
            testsPassed++;
            
            // Clean up
            sceneManager.dispose();
            sphereGeometry.dispose();
            boidSwarm.dispose();
        }
    } catch (error) {
        console.log('❌ Test 6: Component integration - FAILED:', error.message);
    }
    
    // Summary
    console.log('\n📊 Test Results:');
    console.log('================');
    console.log(`Tests Passed: ${testsPassed}/${testsTotal}`);
    console.log(`Success Rate: ${(testsPassed / testsTotal * 100).toFixed(1)}%`);
    
    if (testsPassed === testsTotal) {
        console.log('\n🎉 Phase 2 setup complete! All tests passed.');
        console.log('🌐 Ready for browser testing with: npm run dev');
    } else {
        console.log('\n⚠️  Some tests failed. Check the issues above.');
    }
    
    // Next steps
    console.log('\n📋 Next Steps for Phase 3:');
    console.log('==========================');
    console.log('1. Test in browser with `npm run dev`');
    console.log('2. Verify 3D sphere and camera controls work');
    console.log('3. Add boid simulation integration');
    console.log('4. Implement real-time parameter tuning');
    console.log('5. Add advanced visualization features (trails, colors, etc.)');
    
    return testsPassed === testsTotal;
}

// Run tests
testImports().catch(console.error);