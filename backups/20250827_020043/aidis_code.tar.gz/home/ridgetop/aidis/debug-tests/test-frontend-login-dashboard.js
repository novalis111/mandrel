#!/usr/bin/env node

const { chromium } = require('playwright');

async function testDashboardAfterLogin() {
  let browser;
  try {
    console.log('🚀 Starting browser test with proper login flow...');
    
    // Launch browser
    browser = await chromium.launch({ 
      headless: false,
      args: ['--disable-web-security', '--disable-features=VizDisplayCompositor']
    });
    const context = await browser.newContext();
    const page = await context.newPage();
    
    // Listen to console logs and network
    page.on('console', msg => {
      const text = msg.text();
      if (text.includes('Dashboard API') || text.includes('dashboard stats') || text.includes('fetch') || text.includes('✅')) {
        console.log(`📋 [${msg.type()}] ${text}`);
      }
    });
    
    page.on('request', request => {
      if (request.url().includes('/api/')) {
        console.log(`🌐 ${request.method()} ${request.url()}`);
      }
    });
    
    page.on('response', response => {
      if (response.url().includes('/api/')) {
        console.log(`📡 ${response.status()} ${response.url()}`);
      }
    });
    
    // Navigate to the frontend
    console.log('🌐 Navigating to frontend...');
    await page.goto('http://localhost:3000');
    
    // Wait for page to load and check if we're redirected to login
    await page.waitForTimeout(3000);
    
    const currentUrl = page.url();
    console.log(`📍 Current URL: ${currentUrl}`);
    
    if (currentUrl.includes('/login')) {
      console.log('🔐 Detected login page - performing login...');
      
      // Wait for login form to be visible
      await page.waitForSelector('form', { timeout: 10000 });
      
      // Fill and submit login form (Ant Design inputs)
      await page.fill('input[placeholder="Username"]', 'admin');
      await page.fill('input[placeholder="Password"]', 'admin123!');
      
      console.log('📝 Filled login form');
      
      // Submit the form
      await page.click('button[type="submit"]');
      console.log('🔄 Submitted login form');
      
      // Wait for navigation to dashboard
      await page.waitForURL('**/dashboard', { timeout: 15000 });
      console.log('✅ Successfully navigated to dashboard after login');
      
    } else if (currentUrl.includes('/dashboard')) {
      console.log('🎯 Already on dashboard - user is authenticated');
    } else {
      console.log('⚠️  Unexpected page - checking for redirects...');
      await page.waitForTimeout(5000);
    }
    
    // Now we should be on the dashboard - wait for stats to load
    console.log('📊 Waiting for dashboard stats to load...');
    await page.waitForTimeout(8000);
    
    // Take a screenshot
    await page.screenshot({ path: 'dashboard-after-login.png', fullPage: true });
    console.log('📷 Screenshot saved as dashboard-after-login.png');
    
    // Check for stats values
    try {
      // Look for Ant Design statistic components
      const statValues = await page.$$eval('.ant-statistic-content-value', elements => 
        elements.map(el => ({
          text: el.textContent,
          title: el.closest('.ant-statistic')?.querySelector('.ant-statistic-title')?.textContent
        }))
      );
      
      console.log('📈 Found dashboard statistics:');
      statValues.forEach((stat, index) => {
        console.log(`  ${index + 1}. ${stat.title}: ${stat.text}`);
      });
      
      // Check if we have real data (non-zero values)
      const hasValidData = statValues.some(stat => {
        const num = parseInt(stat.text);
        return !isNaN(num) && num > 0;
      });
      
      if (hasValidData) {
        console.log('✅ SUCCESS: Dashboard is showing real data!');
        
        // Let's also check what's in localStorage
        const authData = await page.evaluate(() => {
          return {
            token: localStorage.getItem('aidis_token'),
            user: localStorage.getItem('aidis_user'),
            hasToken: !!localStorage.getItem('aidis_token')
          };
        });
        
        console.log('🔑 Auth data in localStorage:', {
          hasToken: authData.hasToken,
          tokenLength: authData.token ? authData.token.length : 0,
          userExists: !!authData.user
        });
        
        return true;
      } else {
        console.log('❌ FAILURE: Dashboard stats are still showing 0/null values');
        console.log('💡 This suggests the API calls are still failing');
        
        // Check for error messages on page
        const errors = await page.$$eval('.ant-alert-error, .error', elements => 
          elements.map(el => el.textContent)
        );
        
        if (errors.length > 0) {
          console.log('🚨 Found error messages on page:');
          errors.forEach(error => console.log(`  - ${error}`));
        }
        
        return false;
      }
      
    } catch (error) {
      console.error('❌ Failed to read stats from page:', error.message);
      return false;
    }
    
  } catch (error) {
    console.error('❌ Browser test failed:', error);
    return false;
  } finally {
    if (browser) {
      // Keep browser open for a moment to see the result
      console.log('⏳ Keeping browser open for 10 seconds for inspection...');
      await new Promise(resolve => setTimeout(resolve, 10000));
      await browser.close();
    }
  }
}

async function main() {
  console.log('🧪 Testing dashboard with proper authentication...\n');
  
  const success = await testDashboardAfterLogin();
  
  if (success) {
    console.log('\n🎉 DASHBOARD TEST WITH LOGIN PASSED!');
    console.log('The homepage stats are now working correctly.');
  } else {
    console.log('\n💥 DASHBOARD TEST FAILED!');
    console.log('Even after proper authentication, stats are not showing real data.');
  }
}

main().catch(console.error);
